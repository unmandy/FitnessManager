/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package FitnessManager;


import java.sql.Connection;
import java.awt.Color;
import java.sql.DriverManager;
import javax.swing.JFrame;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author uwaka
 */
public class FitnessManagerManDashboard extends javax.swing.JFrame {
        private static final String username = "root";
        private static final String dataConn = "jdbc:mysql://localhost:3306/fitnessmanager";
        Connection con = null;
        PreparedStatement prep = null;
        ResultSet rs = null;
        int q;

    public FitnessManagerManDashboard() {
        initComponents();
        this.setExtendedState(JFrame.MAXIMIZED_BOTH);
        getContentPane().setBackground(new Color(34,42,47));
    }

    public void updatecustomerDB(){
        try{
            Class.forName("com.mysql.jdbc.Driver"); 
            con = DriverManager.getConnection(dataConn,username,"");
            prep = con.prepareStatement("SELECT * FROM customers WHERE joined = 'Yes'");
            rs = prep.executeQuery();
            ResultSetMetaData stData = rs.getMetaData();
            
            q = stData.getColumnCount();
            
            DefaultTableModel RecordTable = (DefaultTableModel)CustomerAdmission.getModel();
            RecordTable.setRowCount(0);
            
            while(rs.next()){
                Vector columnData = new Vector();
                
                for(int i=1; i<= q; i++){
                    columnData.add(rs.getShort("ID"));
                    columnData.add(rs.getString("customerID"));
                    columnData.add(rs.getString("firstname"));
                    columnData.add(rs.getString("lastname"));
                    columnData.add(rs.getString("email"));                    
                    columnData.add(rs.getString("batch_number"));
                    columnData.add(rs.getString("course_registered"));                    
                    columnData.add(rs.getString("phone_number"));                    
                    columnData.add(rs.getString("payment_method"));
                }
                RecordTable.addRow(columnData);
            }
        }catch(SQLException e){
            JOptionPane.showMessageDialog(null,e);
        } catch (ClassNotFoundException ex) {
            
        }
    }
    
    
    public void updatebookDB(){
        try{
            Class.forName("com.mysql.jdbc.Driver"); 
            con = DriverManager.getConnection(dataConn,username,"");
            prep = con.prepareStatement("SELECT * FROM books");
            rs = prep.executeQuery();
            ResultSetMetaData stData = rs.getMetaData();
            
            q = stData.getColumnCount();
            
            DefaultTableModel RecordTable = (DefaultTableModel)BookDetails.getModel();
            RecordTable.setRowCount(0);
            
            while(rs.next()){
                Vector columnData = new Vector();
                
                for(int i=1; i<= q; i++){
                    columnData.add(rs.getShort("ID"));
                    columnData.add(rs.getString("bookID"));
                    columnData.add(rs.getString("name"));
                    columnData.add(rs.getDouble("price"));
                    columnData.add(rs.getShort("quantity"));
                }
                RecordTable.addRow(columnData);
            }
        }catch(SQLException e){
            JOptionPane.showMessageDialog(null,e);
        } catch (ClassNotFoundException ex) {
            
        }
    }
    
    public void updateemployeeDB(){
        try{
            Class.forName("com.mysql.jdbc.Driver"); 
            con = DriverManager.getConnection(dataConn,username,"");
            prep = con.prepareStatement("SELECT * FROM employees");
            rs = prep.executeQuery();
            ResultSetMetaData stData = rs.getMetaData();
            
            q = stData.getColumnCount();
            
            DefaultTableModel RecordTable = (DefaultTableModel)EmployeeTable.getModel();
            RecordTable.setRowCount(0);
            
            while(rs.next()){
                Vector columnData = new Vector();
                
                for(int i=1; i<= q; i++){
                    columnData.add(rs.getShort("ID"));
                    columnData.add(rs.getString("employeeID"));
                    columnData.add(rs.getString("firstname"));
                    columnData.add(rs.getString("lastname"));
                    columnData.add(rs.getString("email"));
                    columnData.add(rs.getString("course_tutoring"));
                    columnData.add(rs.getString("position"));
                }
                RecordTable.addRow(columnData);
            }
        }catch(SQLException e){
            JOptionPane.showMessageDialog(null,e);
        } catch (ClassNotFoundException ex) {
            
        }
    }
    
    public void updateenqDB(){
        try{
            Class.forName("com.mysql.jdbc.Driver"); 
            con = DriverManager.getConnection(dataConn,username,"");
            prep = con.prepareStatement("SELECT * FROM enquiries");
            rs = prep.executeQuery();
            ResultSetMetaData stData = rs.getMetaData();
            
            q = stData.getColumnCount();
            
            DefaultTableModel RecordTable = (DefaultTableModel)EnquiryTable.getModel();
            RecordTable.setRowCount(0);
            
            while(rs.next()){
                Vector columnData = new Vector();
                
                for(int i=1; i<= q; i++){
                    columnData.add(rs.getShort("ID"));
                    columnData.add(rs.getString("enquiryID"));
                    columnData.add(rs.getString("category"));
                    columnData.add(rs.getString("description"));
                    columnData.add(rs.getString("customerEmail"));
                    columnData.add(rs.getString("date_of_enquiry"));
                }
                RecordTable.addRow(columnData);
            }
        }catch(SQLException e){
            JOptionPane.showMessageDialog(null,e);
        } catch (ClassNotFoundException ex) {
            
        }
    }
    public void updatecourseDB(){
        try{
            Class.forName("com.mysql.jdbc.Driver"); 
            con = DriverManager.getConnection(dataConn,username,"");
            prep = con.prepareStatement("SELECT * FROM courses");
            rs = prep.executeQuery();
            ResultSetMetaData stData = rs.getMetaData();
            
            q = stData.getColumnCount();
            
            DefaultTableModel RecordTable = (DefaultTableModel)CourseTable.getModel();
            RecordTable.setRowCount(0);
            
            while(rs.next()){
                Vector columnData = new Vector();
                
                for(int i=1; i<= q; i++){
                    columnData.add(rs.getShort("ID"));
                    columnData.add(rs.getString("courseID"));
                    columnData.add(rs.getString("name"));
                    columnData.add(rs.getString("fee"));
                    columnData.add(rs.getString("course_duration"));
                }
                RecordTable.addRow(columnData);
            }
        }catch(SQLException e){
            JOptionPane.showMessageDialog(null,e);
        } catch (ClassNotFoundException ex) {
            
        }
    }
    public void updatebatchDB(){
        try{
            Class.forName("com.mysql.jdbc.Driver"); 
            con = DriverManager.getConnection(dataConn,username,"");
            prep = con.prepareStatement("SELECT * FROM batches");
            rs = prep.executeQuery();
            ResultSetMetaData stData = rs.getMetaData();
            
            q = stData.getColumnCount();
            
            DefaultTableModel RecordTable = (DefaultTableModel)BatchTable.getModel();
            RecordTable.setRowCount(0);
            
            while(rs.next()){
                Vector columnData = new Vector();
                
                for(int i=1; i<= q; i++){
                    columnData.add(rs.getShort("ID"));
                    columnData.add(rs.getString("batchID"));
                    columnData.add(rs.getString("course"));
//                    columnData.add(rs.getString("customerID"));
                }
                RecordTable.addRow(columnData);
            }
        }catch(SQLException e){
            JOptionPane.showMessageDialog(null,e);
        } catch (ClassNotFoundException ex) {
            
        }
    }
    public void updatebatch721DB(){
        try{
            Class.forName("com.mysql.jdbc.Driver"); 
            con = DriverManager.getConnection(dataConn,username,"");
            prep = con.prepareStatement("SELECT firstname,lastname FROM customers WHERE batch_number = 721;");
            rs = prep.executeQuery();
            ResultSetMetaData stData = rs.getMetaData();
            
            q = stData.getColumnCount();
            
            DefaultTableModel RecordTable = (DefaultTableModel)batch721.getModel();
            RecordTable.setRowCount(0);
            
            while(rs.next()){
                Vector columnData = new Vector();
                
                for(int i=1; i<= q; i++){
                    columnData.add(rs.getString("firstname"));
                    columnData.add(rs.getString("lastname"));
                }
                RecordTable.addRow(columnData);
            }
        }catch(SQLException e){
            JOptionPane.showMessageDialog(null,e);
        } catch (ClassNotFoundException ex) {
            
        }
    }
    public void updatebatch701DB(){
        try{
            Class.forName("com.mysql.jdbc.Driver"); 
            con = DriverManager.getConnection(dataConn,username,"");
            prep = con.prepareStatement("SELECT firstname,lastname FROM customers WHERE batch_number = 701;");
            rs = prep.executeQuery();
            ResultSetMetaData stData = rs.getMetaData();
            
            q = stData.getColumnCount();
            
            DefaultTableModel RecordTable = (DefaultTableModel)batch701.getModel();
            RecordTable.setRowCount(0);
            
            while(rs.next()){
                Vector columnData = new Vector();
                
                for(int i=1; i<= q; i++){
                    columnData.add(rs.getString("firstname"));
                    columnData.add(rs.getString("lastname"));
                }
                RecordTable.addRow(columnData);
            }
        }catch(SQLException e){
            JOptionPane.showMessageDialog(null,e);
        } catch (ClassNotFoundException ex) {
            
        }
    }
    public void updatebatch798DB(){
        try{
            Class.forName("com.mysql.jdbc.Driver"); 
            con = DriverManager.getConnection(dataConn,username,"");
            prep = con.prepareStatement("SELECT firstname,lastname FROM customers WHERE batch_number = 798;");
            rs = prep.executeQuery();
            ResultSetMetaData stData = rs.getMetaData();
            
            q = stData.getColumnCount();
            
            DefaultTableModel RecordTable = (DefaultTableModel)batch798.getModel();
            RecordTable.setRowCount(0);
            
            while(rs.next()){
                Vector columnData = new Vector();
                
                for(int i=1; i<= q; i++){
                    columnData.add(rs.getString("firstname"));
                    columnData.add(rs.getString("lastname"));
                }
                RecordTable.addRow(columnData);
            }
        }catch(SQLException e){
            JOptionPane.showMessageDialog(null,e);
        } catch (ClassNotFoundException ex) {
            
        }
    }
    public void updatebatch745DB(){
        try{
            Class.forName("com.mysql.jdbc.Driver"); 
            con = DriverManager.getConnection(dataConn,username,"");
            prep = con.prepareStatement("SELECT firstname,lastname FROM customers WHERE batch_number = 745;");
            rs = prep.executeQuery();
            ResultSetMetaData stData = rs.getMetaData();
            
            q = stData.getColumnCount();
            
            DefaultTableModel RecordTable = (DefaultTableModel)batch745.getModel();
            RecordTable.setRowCount(0);
            
            while(rs.next()){
                Vector columnData = new Vector();
                
                for(int i=1; i<= q; i++){
                    columnData.add(rs.getString("firstname"));
                    columnData.add(rs.getString("lastname"));
                }
                RecordTable.addRow(columnData);
            }
        }catch(SQLException e){
            JOptionPane.showMessageDialog(null,e);
        } catch (ClassNotFoundException ex) {
            
        }
    }
    public void updatebatch709DB(){
        try{
            Class.forName("com.mysql.jdbc.Driver"); 
            con = DriverManager.getConnection(dataConn,username,"");
            prep = con.prepareStatement("SELECT firstname,lastname FROM customers WHERE batch_number = 709;");
            rs = prep.executeQuery();
            ResultSetMetaData stData = rs.getMetaData();
            
            q = stData.getColumnCount();
            
            DefaultTableModel RecordTable = (DefaultTableModel)batch709.getModel();
            RecordTable.setRowCount(0);
            
            while(rs.next()){
                Vector columnData = new Vector();
                
                for(int i=1; i<= q; i++){
                    columnData.add(rs.getString("firstname"));
                    columnData.add(rs.getString("lastname"));
                }
                RecordTable.addRow(columnData);
            }
        }catch(SQLException e){
            JOptionPane.showMessageDialog(null,e);
        } catch (ClassNotFoundException ex) {
            
        }
    }
    public void updatebatch789DB(){
        try{
            Class.forName("com.mysql.jdbc.Driver"); 
            con = DriverManager.getConnection(dataConn,username,"");
            prep = con.prepareStatement("SELECT firstname,lastname FROM customers WHERE batch_number = 789;");
            rs = prep.executeQuery();
            ResultSetMetaData stData = rs.getMetaData();
            
            q = stData.getColumnCount();
            
            DefaultTableModel RecordTable = (DefaultTableModel)batch789.getModel();
            RecordTable.setRowCount(0);
            
            while(rs.next()){
                Vector columnData = new Vector();
                
                for(int i=1; i<= q; i++){
                    columnData.add(rs.getString("firstname"));
                    columnData.add(rs.getString("lastname"));
                }
                RecordTable.addRow(columnData);
            }
        }catch(SQLException e){
            JOptionPane.showMessageDialog(null,e);
        } catch (ClassNotFoundException ex) {
            
        }
    }
    public void updatebatch734DB(){
        try{
            Class.forName("com.mysql.jdbc.Driver"); 
            con = DriverManager.getConnection(dataConn,username,"");
            prep = con.prepareStatement("SELECT firstname,lastname FROM customers WHERE batch_number = 734;");
            rs = prep.executeQuery();
            ResultSetMetaData stData = rs.getMetaData();
            
            q = stData.getColumnCount();
            
            DefaultTableModel RecordTable = (DefaultTableModel)batch734.getModel();
            RecordTable.setRowCount(0);
            
            while(rs.next()){
                Vector columnData = new Vector();
                
                for(int i=1; i<= q; i++){
                    columnData.add(rs.getString("firstname"));
                    columnData.add(rs.getString("lastname"));
                }
                RecordTable.addRow(columnData);
            }
        }catch(SQLException e){
            JOptionPane.showMessageDialog(null,e);
        } catch (ClassNotFoundException ex) {
            
        }
    }
    public void updatebatch777DB(){
        try{
            Class.forName("com.mysql.jdbc.Driver"); 
            con = DriverManager.getConnection(dataConn,username,"");
            prep = con.prepareStatement("SELECT firstname,lastname FROM customers WHERE batch_number = 777;");
            rs = prep.executeQuery();
            ResultSetMetaData stData = rs.getMetaData();
            
            q = stData.getColumnCount();
            
            DefaultTableModel RecordTable = (DefaultTableModel)batch777.getModel();
            RecordTable.setRowCount(0);
            
            while(rs.next()){
                Vector columnData = new Vector();
                
                for(int i=1; i<= q; i++){
                    columnData.add(rs.getString("firstname"));
                    columnData.add(rs.getString("lastname"));
                }
                RecordTable.addRow(columnData);
            }
        }catch(SQLException e){
            JOptionPane.showMessageDialog(null,e);
        } catch (ClassNotFoundException ex) {
            
        }
    }
    public void updatebatch788DB(){
        try{
            Class.forName("com.mysql.jdbc.Driver"); 
            con = DriverManager.getConnection(dataConn,username,"");
            prep = con.prepareStatement("SELECT firstname,lastname FROM customers WHERE batch_number = 788;");
            rs = prep.executeQuery();
            ResultSetMetaData stData = rs.getMetaData();
            
            q = stData.getColumnCount();
            
            DefaultTableModel RecordTable = (DefaultTableModel)batch788.getModel();
            RecordTable.setRowCount(0);
            
            while(rs.next()){
                Vector columnData = new Vector();
                
                for(int i=1; i<= q; i++){
                    columnData.add(rs.getString("firstname"));
                    columnData.add(rs.getString("lastname"));
                }
                RecordTable.addRow(columnData);
            }
        }catch(SQLException e){
            JOptionPane.showMessageDialog(null,e);
        } catch (ClassNotFoundException ex) {
            
        }
    }
    public void updatebatch799DB(){
        try{
            Class.forName("com.mysql.jdbc.Driver"); 
            con = DriverManager.getConnection(dataConn,username,"");
            prep = con.prepareStatement("SELECT firstname,lastname FROM customers WHERE batch_number = 799;");
            rs = prep.executeQuery();
            ResultSetMetaData stData = rs.getMetaData();
            
            q = stData.getColumnCount();
            
            DefaultTableModel RecordTable = (DefaultTableModel)batch799.getModel();
            RecordTable.setRowCount(0);
            
            while(rs.next()){
                Vector columnData = new Vector();
                
                for(int i=1; i<= q; i++){
                    columnData.add(rs.getString("firstname"));
                    columnData.add(rs.getString("lastname"));
                }
                RecordTable.addRow(columnData);
            }
        }catch(SQLException e){
            JOptionPane.showMessageDialog(null,e);
        } catch (ClassNotFoundException ex) {
            
        }
    }
    public void updatebatch767DB(){
        try{
            Class.forName("com.mysql.jdbc.Driver"); 
            con = DriverManager.getConnection(dataConn,username,"");
            prep = con.prepareStatement("SELECT firstname,lastname FROM customers WHERE batch_number = 767;");
            rs = prep.executeQuery();
            ResultSetMetaData stData = rs.getMetaData();
            
            q = stData.getColumnCount();
            
            DefaultTableModel RecordTable = (DefaultTableModel)batch767.getModel();
            RecordTable.setRowCount(0);
            
            while(rs.next()){
                Vector columnData = new Vector();
                
                for(int i=1; i<= q; i++){
                    columnData.add(rs.getString("firstname"));
                    columnData.add(rs.getString("lastname"));
                }
                RecordTable.addRow(columnData);
            }
        }catch(SQLException e){
            JOptionPane.showMessageDialog(null,e);
        } catch (ClassNotFoundException ex) {
            
        }
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        panelHeader = new javax.swing.JPanel();
        ManagerName = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        panelMenu = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        dashboardbtn = new FitnessManager.PanelRound();
        jLabel56 = new javax.swing.JLabel();
        booksbtn = new FitnessManager.PanelRound();
        jLabel57 = new javax.swing.JLabel();
        employeebtn = new FitnessManager.PanelRound();
        jLabel58 = new javax.swing.JLabel();
        fitnessbtn = new FitnessManager.PanelRound();
        jLabel59 = new javax.swing.JLabel();
        enquiriesbtn = new FitnessManager.PanelRound();
        jLabel60 = new javax.swing.JLabel();
        admissionbtn = new FitnessManager.PanelRound();
        jLabel18 = new javax.swing.JLabel();
        coursesbtn = new FitnessManager.PanelRound();
        jLabel78 = new javax.swing.JLabel();
        batchesbtn = new FitnessManager.PanelRound();
        jLabel79 = new javax.swing.JLabel();
        schedulesbtn = new FitnessManager.PanelRound();
        jLabel80 = new javax.swing.JLabel();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        Dashboard = new javax.swing.JPanel();
        panelRound1 = new FitnessManager.PanelRound();
        panelRound2 = new FitnessManager.PanelRound();
        jLabel4 = new javax.swing.JLabel();
        panelRound3 = new FitnessManager.PanelRound();
        jLabel10 = new javax.swing.JLabel();
        panelRound5 = new FitnessManager.PanelRound();
        jLabel5 = new javax.swing.JLabel();
        panelRound6 = new FitnessManager.PanelRound();
        jLabel11 = new javax.swing.JLabel();
        panelRound7 = new FitnessManager.PanelRound();
        jLabel6 = new javax.swing.JLabel();
        panelRound8 = new FitnessManager.PanelRound();
        jLabel12 = new javax.swing.JLabel();
        panelRound9 = new FitnessManager.PanelRound();
        jLabel7 = new javax.swing.JLabel();
        panelRound10 = new FitnessManager.PanelRound();
        jLabel13 = new javax.swing.JLabel();
        panelRound11 = new FitnessManager.PanelRound();
        jLabel8 = new javax.swing.JLabel();
        panelRound12 = new FitnessManager.PanelRound();
        jLabel14 = new javax.swing.JLabel();
        panelRound13 = new FitnessManager.PanelRound();
        jLabel9 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        panelRound14 = new FitnessManager.PanelRound();
        jLabel1 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        panelRound16 = new FitnessManager.PanelRound();
        jLabel19 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        panelRound17 = new FitnessManager.PanelRound();
        jLabel20 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        panelRound15 = new FitnessManager.PanelRound();
        jLabel21 = new javax.swing.JLabel();
        jLabel24 = new javax.swing.JLabel();
        jCalendar1 = new com.toedter.calendar.JCalendar();
        jLabel15 = new javax.swing.JLabel();
        Books = new javax.swing.JPanel();
        jLabel31 = new javax.swing.JLabel();
        panelRound21 = new FitnessManager.PanelRound();
        jPanel5 = new javax.swing.JPanel();
        jLabel32 = new javax.swing.JLabel();
        bookID = new javax.swing.JTextField();
        jLabel33 = new javax.swing.JLabel();
        name = new javax.swing.JTextField();
        jLabel34 = new javax.swing.JLabel();
        price = new javax.swing.JTextField();
        jLabel35 = new javax.swing.JLabel();
        quantity = new javax.swing.JTextField();
        panelRound22 = new FitnessManager.PanelRound();
        jScrollPane2 = new javax.swing.JScrollPane();
        BookDetails = new javax.swing.JTable();
        panelRound23 = new FitnessManager.PanelRound();
        addbookbtn = new FitnessManager.PanelRound();
        jLabel36 = new javax.swing.JLabel();
        updatebookbtn = new FitnessManager.PanelRound();
        jLabel37 = new javax.swing.JLabel();
        deletebookbtn = new FitnessManager.PanelRound();
        jLabel38 = new javax.swing.JLabel();
        resetbookbtn = new FitnessManager.PanelRound();
        jLabel39 = new javax.swing.JLabel();
        viewData = new FitnessManager.PanelRound();
        jLabel40 = new javax.swing.JLabel();
        Employee = new javax.swing.JPanel();
        jLabel42 = new javax.swing.JLabel();
        panelRound24 = new FitnessManager.PanelRound();
        jPanel6 = new javax.swing.JPanel();
        jLabel43 = new javax.swing.JLabel();
        employeeID = new javax.swing.JTextField();
        jLabel44 = new javax.swing.JLabel();
        empFirstName = new javax.swing.JTextField();
        jLabel45 = new javax.swing.JLabel();
        empLastName = new javax.swing.JTextField();
        jLabel53 = new javax.swing.JLabel();
        empEmail = new javax.swing.JTextField();
        jLabel46 = new javax.swing.JLabel();
        course_tutoring = new javax.swing.JComboBox<>();
        jLabel47 = new javax.swing.JLabel();
        position = new javax.swing.JComboBox<>();
        panelRound25 = new FitnessManager.PanelRound();
        jScrollPane3 = new javax.swing.JScrollPane();
        EmployeeTable = new javax.swing.JTable();
        panelRound27 = new FitnessManager.PanelRound();
        addempbtn = new FitnessManager.PanelRound();
        jLabel48 = new javax.swing.JLabel();
        updateempbtn = new FitnessManager.PanelRound();
        jLabel49 = new javax.swing.JLabel();
        deleteempbtn = new FitnessManager.PanelRound();
        jLabel50 = new javax.swing.JLabel();
        resetempbtn = new FitnessManager.PanelRound();
        jLabel51 = new javax.swing.JLabel();
        viewEmpDatabtn = new FitnessManager.PanelRound();
        jLabel52 = new javax.swing.JLabel();
        Enquiries = new javax.swing.JPanel();
        jLabel54 = new javax.swing.JLabel();
        panelRound26 = new FitnessManager.PanelRound();
        jScrollPane4 = new javax.swing.JScrollPane();
        EnquiryTable = new javax.swing.JTable();
        viewEnqDatabtn = new FitnessManager.PanelRound();
        jLabel55 = new javax.swing.JLabel();
        Admission = new javax.swing.JPanel();
        panelRound4 = new FitnessManager.PanelRound();
        jScrollPane1 = new javax.swing.JScrollPane();
        CustomerAdmission = new javax.swing.JTable();
        jLabel25 = new javax.swing.JLabel();
        panelRound19 = new FitnessManager.PanelRound();
        adddeetsbtn = new FitnessManager.PanelRound();
        jLabel26 = new javax.swing.JLabel();
        updatedeetsbtn = new FitnessManager.PanelRound();
        jLabel28 = new javax.swing.JLabel();
        viewCustomerDatabtn = new FitnessManager.PanelRound();
        jLabel41 = new javax.swing.JLabel();
        resetbtn = new FitnessManager.PanelRound();
        jLabel29 = new javax.swing.JLabel();
        panelRound20 = new FitnessManager.PanelRound();
        jPanel4 = new javax.swing.JPanel();
        jLabel27 = new javax.swing.JLabel();
        customerID = new javax.swing.JTextField();
        Courses = new javax.swing.JPanel();
        jLabel61 = new javax.swing.JLabel();
        panelRound18 = new FitnessManager.PanelRound();
        jScrollPane5 = new javax.swing.JScrollPane();
        CourseTable = new javax.swing.JTable();
        panelRound28 = new FitnessManager.PanelRound();
        viewCourseDatabtn = new FitnessManager.PanelRound();
        jLabel66 = new javax.swing.JLabel();
        addcoursebtn = new FitnessManager.PanelRound();
        jLabel67 = new javax.swing.JLabel();
        updatecoursebtn = new FitnessManager.PanelRound();
        jLabel68 = new javax.swing.JLabel();
        delcoursebtn = new FitnessManager.PanelRound();
        jLabel69 = new javax.swing.JLabel();
        resetcoursebtn = new FitnessManager.PanelRound();
        jLabel70 = new javax.swing.JLabel();
        panelRound29 = new FitnessManager.PanelRound();
        jPanel7 = new javax.swing.JPanel();
        jLabel62 = new javax.swing.JLabel();
        courseID = new javax.swing.JTextField();
        jLabel63 = new javax.swing.JLabel();
        courseName = new javax.swing.JTextField();
        jLabel64 = new javax.swing.JLabel();
        fee = new javax.swing.JTextField();
        jLabel65 = new javax.swing.JLabel();
        duration = new javax.swing.JTextField();
        Batches = new javax.swing.JPanel();
        jLabel71 = new javax.swing.JLabel();
        panelRound30 = new FitnessManager.PanelRound();
        jScrollPane6 = new javax.swing.JScrollPane();
        BatchTable = new javax.swing.JTable();
        panelRound31 = new FitnessManager.PanelRound();
        jPanel8 = new javax.swing.JPanel();
        jLabel72 = new javax.swing.JLabel();
        batchID = new javax.swing.JTextField();
        jLabel73 = new javax.swing.JLabel();
        batch_courses = new javax.swing.JComboBox<>();
        panelRound32 = new FitnessManager.PanelRound();
        viewBatchDatabtn = new FitnessManager.PanelRound();
        jLabel74 = new javax.swing.JLabel();
        addBatchbtn = new FitnessManager.PanelRound();
        jLabel76 = new javax.swing.JLabel();
        updateBatchbtn = new FitnessManager.PanelRound();
        jLabel75 = new javax.swing.JLabel();
        delBatchbtn = new FitnessManager.PanelRound();
        jLabel77 = new javax.swing.JLabel();
        panelRound35 = new FitnessManager.PanelRound();
        batch701btn = new javax.swing.JLabel();
        jScrollPane7 = new javax.swing.JScrollPane();
        batch701 = new javax.swing.JTable();
        panelRound36 = new FitnessManager.PanelRound();
        batch721btn = new javax.swing.JLabel();
        jScrollPane8 = new javax.swing.JScrollPane();
        batch721 = new javax.swing.JTable();
        panelRound37 = new FitnessManager.PanelRound();
        batch798btn = new javax.swing.JLabel();
        jScrollPane9 = new javax.swing.JScrollPane();
        batch798 = new javax.swing.JTable();
        panelRound39 = new FitnessManager.PanelRound();
        batch745btn = new javax.swing.JLabel();
        jScrollPane11 = new javax.swing.JScrollPane();
        batch745 = new javax.swing.JTable();
        panelRound40 = new FitnessManager.PanelRound();
        batch789btn = new javax.swing.JLabel();
        jScrollPane12 = new javax.swing.JScrollPane();
        batch789 = new javax.swing.JTable();
        panelRound41 = new FitnessManager.PanelRound();
        batch709btn = new javax.swing.JLabel();
        jScrollPane13 = new javax.swing.JScrollPane();
        batch709 = new javax.swing.JTable();
        panelRound44 = new FitnessManager.PanelRound();
        batch767btn = new javax.swing.JLabel();
        jScrollPane16 = new javax.swing.JScrollPane();
        batch767 = new javax.swing.JTable();
        panelRound42 = new FitnessManager.PanelRound();
        batch734btn = new javax.swing.JLabel();
        jScrollPane14 = new javax.swing.JScrollPane();
        batch734 = new javax.swing.JTable();
        panelRound43 = new FitnessManager.PanelRound();
        batch777btn = new javax.swing.JLabel();
        jScrollPane15 = new javax.swing.JScrollPane();
        batch777 = new javax.swing.JTable();
        panelRound46 = new FitnessManager.PanelRound();
        batch788btn = new javax.swing.JLabel();
        jScrollPane18 = new javax.swing.JScrollPane();
        batch788 = new javax.swing.JTable();
        panelRound47 = new FitnessManager.PanelRound();
        batch799btn = new javax.swing.JLabel();
        jScrollPane19 = new javax.swing.JScrollPane();
        batch799 = new javax.swing.JTable();
        Schedules = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Fitness Manager");
        setResizable(false);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(0, 0, 0));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        panelHeader.setBackground(new java.awt.Color(23, 23, 23));
        panelHeader.setPreferredSize(new java.awt.Dimension(200, 100));

        ManagerName.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        ManagerName.setForeground(new java.awt.Color(255, 255, 255));

        jLabel2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Welcome");

        javax.swing.GroupLayout panelHeaderLayout = new javax.swing.GroupLayout(panelHeader);
        panelHeader.setLayout(panelHeaderLayout);
        panelHeaderLayout.setHorizontalGroup(
            panelHeaderLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelHeaderLayout.createSequentialGroup()
                .addGap(255, 255, 255)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(ManagerName, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(879, Short.MAX_VALUE))
        );
        panelHeaderLayout.setVerticalGroup(
            panelHeaderLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelHeaderLayout.createSequentialGroup()
                .addContainerGap(14, Short.MAX_VALUE)
                .addGroup(panelHeaderLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(ManagerName, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        jPanel1.add(panelHeader, new org.netbeans.lib.awtextra.AbsoluteConstraints(-3, 0, 1320, 40));

        panelMenu.setBackground(new java.awt.Color(23, 23, 23));

        jPanel2.setBackground(new java.awt.Color(23, 23, 23));
        jPanel2.setPreferredSize(new java.awt.Dimension(50, 100));
        jPanel2.setLayout(new java.awt.GridLayout(9, 1, 0, 5));

        dashboardbtn.setBackground(new java.awt.Color(16, 16, 16));
        dashboardbtn.setRoundBottomLeft(30);
        dashboardbtn.setRoundBottomRight(30);
        dashboardbtn.setRoundTopLeft(30);
        dashboardbtn.setRoundTopRight(30);
        dashboardbtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                dashboardbtnMousePressed(evt);
            }
        });

        jLabel56.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel56.setForeground(new java.awt.Color(255, 255, 255));
        jLabel56.setIcon(new javax.swing.ImageIcon(getClass().getResource("/FitnessManager/images/icons8_dashboard_layout_32.png"))); // NOI18N
        jLabel56.setText("Dashboard");
        jLabel56.setIconTextGap(15);

        javax.swing.GroupLayout dashboardbtnLayout = new javax.swing.GroupLayout(dashboardbtn);
        dashboardbtn.setLayout(dashboardbtnLayout);
        dashboardbtnLayout.setHorizontalGroup(
            dashboardbtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 242, Short.MAX_VALUE)
            .addGroup(dashboardbtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(dashboardbtnLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jLabel56)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        dashboardbtnLayout.setVerticalGroup(
            dashboardbtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 47, Short.MAX_VALUE)
            .addGroup(dashboardbtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(dashboardbtnLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jLabel56)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );

        jPanel2.add(dashboardbtn);

        booksbtn.setBackground(new java.awt.Color(16, 16, 16));
        booksbtn.setRoundBottomLeft(30);
        booksbtn.setRoundBottomRight(30);
        booksbtn.setRoundTopLeft(30);
        booksbtn.setRoundTopRight(30);
        booksbtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                booksbtnMousePressed(evt);
            }
        });

        jLabel57.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel57.setForeground(new java.awt.Color(255, 255, 255));
        jLabel57.setIcon(new javax.swing.ImageIcon(getClass().getResource("/FitnessManager/images/icons8_Books_32.png"))); // NOI18N
        jLabel57.setText("Books");
        jLabel57.setIconTextGap(15);

        javax.swing.GroupLayout booksbtnLayout = new javax.swing.GroupLayout(booksbtn);
        booksbtn.setLayout(booksbtnLayout);
        booksbtnLayout.setHorizontalGroup(
            booksbtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 242, Short.MAX_VALUE)
            .addGroup(booksbtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, booksbtnLayout.createSequentialGroup()
                    .addContainerGap(51, Short.MAX_VALUE)
                    .addComponent(jLabel57, javax.swing.GroupLayout.PREFERRED_SIZE, 119, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(72, Short.MAX_VALUE)))
        );
        booksbtnLayout.setVerticalGroup(
            booksbtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 47, Short.MAX_VALUE)
            .addGroup(booksbtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, booksbtnLayout.createSequentialGroup()
                    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel57)
                    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
        );

        jPanel2.add(booksbtn);

        employeebtn.setBackground(new java.awt.Color(16, 16, 16));
        employeebtn.setRoundBottomLeft(30);
        employeebtn.setRoundBottomRight(30);
        employeebtn.setRoundTopLeft(30);
        employeebtn.setRoundTopRight(30);
        employeebtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                employeebtnMousePressed(evt);
            }
        });

        jLabel58.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel58.setForeground(new java.awt.Color(255, 255, 255));
        jLabel58.setIcon(new javax.swing.ImageIcon(getClass().getResource("/FitnessManager/images/icons8_manager_32.png"))); // NOI18N
        jLabel58.setText("Employee");
        jLabel58.setIconTextGap(15);

        javax.swing.GroupLayout employeebtnLayout = new javax.swing.GroupLayout(employeebtn);
        employeebtn.setLayout(employeebtnLayout);
        employeebtnLayout.setHorizontalGroup(
            employeebtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 242, Short.MAX_VALUE)
            .addGroup(employeebtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, employeebtnLayout.createSequentialGroup()
                    .addContainerGap(47, Short.MAX_VALUE)
                    .addComponent(jLabel58, javax.swing.GroupLayout.PREFERRED_SIZE, 139, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(56, Short.MAX_VALUE)))
        );
        employeebtnLayout.setVerticalGroup(
            employeebtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 47, Short.MAX_VALUE)
            .addGroup(employeebtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, employeebtnLayout.createSequentialGroup()
                    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel58)
                    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
        );

        jPanel2.add(employeebtn);

        fitnessbtn.setBackground(new java.awt.Color(16, 16, 16));
        fitnessbtn.setRoundBottomLeft(30);
        fitnessbtn.setRoundBottomRight(30);
        fitnessbtn.setRoundTopLeft(30);
        fitnessbtn.setRoundTopRight(30);
        fitnessbtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                fitnessbtnMousePressed(evt);
            }
        });

        jLabel59.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel59.setForeground(new java.awt.Color(255, 255, 255));
        jLabel59.setIcon(new javax.swing.ImageIcon(getClass().getResource("/FitnessManager/images/icons8_dumbbell_32.png"))); // NOI18N
        jLabel59.setText("Fitness Section");
        jLabel59.setIconTextGap(15);

        javax.swing.GroupLayout fitnessbtnLayout = new javax.swing.GroupLayout(fitnessbtn);
        fitnessbtn.setLayout(fitnessbtnLayout);
        fitnessbtnLayout.setHorizontalGroup(
            fitnessbtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, fitnessbtnLayout.createSequentialGroup()
                .addContainerGap(45, Short.MAX_VALUE)
                .addComponent(jLabel59)
                .addGap(23, 23, 23))
        );
        fitnessbtnLayout.setVerticalGroup(
            fitnessbtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(fitnessbtnLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel59)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel2.add(fitnessbtn);

        enquiriesbtn.setBackground(new java.awt.Color(16, 16, 16));
        enquiriesbtn.setRoundBottomLeft(30);
        enquiriesbtn.setRoundBottomRight(30);
        enquiriesbtn.setRoundTopLeft(30);
        enquiriesbtn.setRoundTopRight(30);
        enquiriesbtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                enquiriesbtnMousePressed(evt);
            }
        });

        jLabel60.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel60.setForeground(new java.awt.Color(255, 255, 255));
        jLabel60.setIcon(new javax.swing.ImageIcon(getClass().getResource("/FitnessManager/images/icons8_questions_32.png"))); // NOI18N
        jLabel60.setText("Enquiries");
        jLabel60.setIconTextGap(15);

        javax.swing.GroupLayout enquiriesbtnLayout = new javax.swing.GroupLayout(enquiriesbtn);
        enquiriesbtn.setLayout(enquiriesbtnLayout);
        enquiriesbtnLayout.setHorizontalGroup(
            enquiriesbtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 242, Short.MAX_VALUE)
            .addGroup(enquiriesbtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, enquiriesbtnLayout.createSequentialGroup()
                    .addContainerGap(46, Short.MAX_VALUE)
                    .addComponent(jLabel60, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(59, Short.MAX_VALUE)))
        );
        enquiriesbtnLayout.setVerticalGroup(
            enquiriesbtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 47, Short.MAX_VALUE)
            .addGroup(enquiriesbtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, enquiriesbtnLayout.createSequentialGroup()
                    .addContainerGap(7, Short.MAX_VALUE)
                    .addComponent(jLabel60)
                    .addContainerGap(8, Short.MAX_VALUE)))
        );

        jPanel2.add(enquiriesbtn);

        admissionbtn.setBackground(new java.awt.Color(16, 16, 16));
        admissionbtn.setRoundBottomLeft(30);
        admissionbtn.setRoundBottomRight(30);
        admissionbtn.setRoundTopLeft(30);
        admissionbtn.setRoundTopRight(30);
        admissionbtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                admissionbtnMousePressed(evt);
            }
        });

        jLabel18.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel18.setForeground(new java.awt.Color(255, 255, 255));
        jLabel18.setIcon(new javax.swing.ImageIcon(getClass().getResource("/FitnessManager/images/icons8_user_32.png"))); // NOI18N
        jLabel18.setText("Admission");
        jLabel18.setIconTextGap(15);

        javax.swing.GroupLayout admissionbtnLayout = new javax.swing.GroupLayout(admissionbtn);
        admissionbtn.setLayout(admissionbtnLayout);
        admissionbtnLayout.setHorizontalGroup(
            admissionbtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 242, Short.MAX_VALUE)
            .addGroup(admissionbtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, admissionbtnLayout.createSequentialGroup()
                    .addContainerGap(45, Short.MAX_VALUE)
                    .addComponent(jLabel18, javax.swing.GroupLayout.PREFERRED_SIZE, 144, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(53, Short.MAX_VALUE)))
        );
        admissionbtnLayout.setVerticalGroup(
            admissionbtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 47, Short.MAX_VALUE)
            .addGroup(admissionbtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, admissionbtnLayout.createSequentialGroup()
                    .addContainerGap(7, Short.MAX_VALUE)
                    .addComponent(jLabel18)
                    .addContainerGap(8, Short.MAX_VALUE)))
        );

        jPanel2.add(admissionbtn);

        coursesbtn.setBackground(new java.awt.Color(16, 16, 16));
        coursesbtn.setRoundBottomLeft(30);
        coursesbtn.setRoundBottomRight(30);
        coursesbtn.setRoundTopLeft(30);
        coursesbtn.setRoundTopRight(30);
        coursesbtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                coursesbtnMousePressed(evt);
            }
        });

        jLabel78.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel78.setForeground(new java.awt.Color(255, 255, 255));
        jLabel78.setIcon(new javax.swing.ImageIcon(getClass().getResource("/FitnessManager/images/icons8_content_32.png"))); // NOI18N
        jLabel78.setText("Courses");
        jLabel78.setIconTextGap(15);
        jLabel78.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jLabel78MousePressed(evt);
            }
        });

        javax.swing.GroupLayout coursesbtnLayout = new javax.swing.GroupLayout(coursesbtn);
        coursesbtn.setLayout(coursesbtnLayout);
        coursesbtnLayout.setHorizontalGroup(
            coursesbtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, coursesbtnLayout.createSequentialGroup()
                .addContainerGap(48, Short.MAX_VALUE)
                .addComponent(jLabel78, javax.swing.GroupLayout.PREFERRED_SIZE, 171, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(23, 23, 23))
        );
        coursesbtnLayout.setVerticalGroup(
            coursesbtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(coursesbtnLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel78)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel2.add(coursesbtn);

        batchesbtn.setBackground(new java.awt.Color(16, 16, 16));
        batchesbtn.setRoundBottomLeft(30);
        batchesbtn.setRoundBottomRight(30);
        batchesbtn.setRoundTopLeft(30);
        batchesbtn.setRoundTopRight(30);
        batchesbtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                batchesbtnMousePressed(evt);
            }
        });

        jLabel79.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel79.setForeground(new java.awt.Color(255, 255, 255));
        jLabel79.setIcon(new javax.swing.ImageIcon(getClass().getResource("/FitnessManager/images/icons8_batch_assign_32.png"))); // NOI18N
        jLabel79.setText("Batches");
        jLabel79.setIconTextGap(15);

        javax.swing.GroupLayout batchesbtnLayout = new javax.swing.GroupLayout(batchesbtn);
        batchesbtn.setLayout(batchesbtnLayout);
        batchesbtnLayout.setHorizontalGroup(
            batchesbtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 242, Short.MAX_VALUE)
            .addGroup(batchesbtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, batchesbtnLayout.createSequentialGroup()
                    .addContainerGap(50, Short.MAX_VALUE)
                    .addComponent(jLabel79, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(59, Short.MAX_VALUE)))
        );
        batchesbtnLayout.setVerticalGroup(
            batchesbtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 47, Short.MAX_VALUE)
            .addGroup(batchesbtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, batchesbtnLayout.createSequentialGroup()
                    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel79)
                    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
        );

        jPanel2.add(batchesbtn);

        schedulesbtn.setBackground(new java.awt.Color(16, 16, 16));
        schedulesbtn.setRoundBottomLeft(30);
        schedulesbtn.setRoundBottomRight(30);
        schedulesbtn.setRoundTopLeft(30);
        schedulesbtn.setRoundTopRight(30);
        schedulesbtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                schedulesbtnMousePressed(evt);
            }
        });

        jLabel80.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel80.setForeground(new java.awt.Color(255, 255, 255));
        jLabel80.setIcon(new javax.swing.ImageIcon(getClass().getResource("/FitnessManager/images/icons8_schedule_32.png"))); // NOI18N
        jLabel80.setText("Schedules");
        jLabel80.setIconTextGap(15);

        javax.swing.GroupLayout schedulesbtnLayout = new javax.swing.GroupLayout(schedulesbtn);
        schedulesbtn.setLayout(schedulesbtnLayout);
        schedulesbtnLayout.setHorizontalGroup(
            schedulesbtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 242, Short.MAX_VALUE)
            .addGroup(schedulesbtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, schedulesbtnLayout.createSequentialGroup()
                    .addContainerGap(47, Short.MAX_VALUE)
                    .addComponent(jLabel80, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(55, Short.MAX_VALUE)))
        );
        schedulesbtnLayout.setVerticalGroup(
            schedulesbtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 47, Short.MAX_VALUE)
            .addGroup(schedulesbtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, schedulesbtnLayout.createSequentialGroup()
                    .addContainerGap(7, Short.MAX_VALUE)
                    .addComponent(jLabel80)
                    .addContainerGap(8, Short.MAX_VALUE)))
        );

        jPanel2.add(schedulesbtn);

        javax.swing.GroupLayout panelMenuLayout = new javax.swing.GroupLayout(panelMenu);
        panelMenu.setLayout(panelMenuLayout);
        panelMenuLayout.setHorizontalGroup(
            panelMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelMenuLayout.createSequentialGroup()
                .addGap(0, 0, 0)
                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, 242, Short.MAX_VALUE)
                .addGap(0, 0, 0))
        );
        panelMenuLayout.setVerticalGroup(
            panelMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelMenuLayout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, 465, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(237, Short.MAX_VALUE))
        );

        jPanel1.add(panelMenu, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 40, 242, 730));

        Dashboard.setBackground(new java.awt.Color(0, 0, 0));

        panelRound1.setBackground(new java.awt.Color(16, 16, 16));
        panelRound1.setRoundBottomLeft(30);
        panelRound1.setRoundBottomRight(30);
        panelRound1.setRoundTopLeft(30);
        panelRound1.setRoundTopRight(30);
        panelRound1.setLayout(new java.awt.GridLayout(6, 2, 2, 3));

        panelRound2.setBackground(new java.awt.Color(255, 144, 69));
        panelRound2.setRoundBottomLeft(30);
        panelRound2.setRoundBottomRight(30);
        panelRound2.setRoundTopLeft(30);
        panelRound2.setRoundTopRight(30);

        jLabel4.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("One-on-one personal training");

        javax.swing.GroupLayout panelRound2Layout = new javax.swing.GroupLayout(panelRound2);
        panelRound2.setLayout(panelRound2Layout);
        panelRound2Layout.setHorizontalGroup(
            panelRound2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 236, Short.MAX_VALUE)
            .addGroup(panelRound2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(panelRound2Layout.createSequentialGroup()
                    .addGap(0, 26, Short.MAX_VALUE)
                    .addComponent(jLabel4)
                    .addGap(0, 26, Short.MAX_VALUE)))
        );
        panelRound2Layout.setVerticalGroup(
            panelRound2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 67, Short.MAX_VALUE)
            .addGroup(panelRound2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(panelRound2Layout.createSequentialGroup()
                    .addGap(0, 23, Short.MAX_VALUE)
                    .addComponent(jLabel4)
                    .addGap(0, 24, Short.MAX_VALUE)))
        );

        panelRound1.add(panelRound2);

        panelRound3.setBackground(new java.awt.Color(255, 144, 69));
        panelRound3.setRoundBottomLeft(30);
        panelRound3.setRoundBottomRight(30);
        panelRound3.setRoundTopLeft(30);
        panelRound3.setRoundTopRight(30);

        jLabel10.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setText("Muscle toning");

        javax.swing.GroupLayout panelRound3Layout = new javax.swing.GroupLayout(panelRound3);
        panelRound3.setLayout(panelRound3Layout);
        panelRound3Layout.setHorizontalGroup(
            panelRound3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 236, Short.MAX_VALUE)
            .addGroup(panelRound3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(panelRound3Layout.createSequentialGroup()
                    .addGap(0, 74, Short.MAX_VALUE)
                    .addComponent(jLabel10)
                    .addGap(0, 74, Short.MAX_VALUE)))
        );
        panelRound3Layout.setVerticalGroup(
            panelRound3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 67, Short.MAX_VALUE)
            .addGroup(panelRound3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(panelRound3Layout.createSequentialGroup()
                    .addGap(0, 23, Short.MAX_VALUE)
                    .addComponent(jLabel10)
                    .addGap(0, 24, Short.MAX_VALUE)))
        );

        panelRound1.add(panelRound3);

        panelRound5.setBackground(new java.awt.Color(255, 144, 69));
        panelRound5.setRoundBottomLeft(30);
        panelRound5.setRoundBottomRight(30);
        panelRound5.setRoundTopLeft(30);
        panelRound5.setRoundTopRight(30);

        jLabel5.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Physical fitness training");

        javax.swing.GroupLayout panelRound5Layout = new javax.swing.GroupLayout(panelRound5);
        panelRound5.setLayout(panelRound5Layout);
        panelRound5Layout.setHorizontalGroup(
            panelRound5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 236, Short.MAX_VALUE)
            .addGroup(panelRound5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(panelRound5Layout.createSequentialGroup()
                    .addGap(0, 46, Short.MAX_VALUE)
                    .addComponent(jLabel5)
                    .addGap(0, 45, Short.MAX_VALUE)))
        );
        panelRound5Layout.setVerticalGroup(
            panelRound5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 67, Short.MAX_VALUE)
            .addGroup(panelRound5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(panelRound5Layout.createSequentialGroup()
                    .addGap(0, 23, Short.MAX_VALUE)
                    .addComponent(jLabel5)
                    .addGap(0, 24, Short.MAX_VALUE)))
        );

        panelRound1.add(panelRound5);

        panelRound6.setBackground(new java.awt.Color(255, 144, 69));
        panelRound6.setRoundBottomLeft(30);
        panelRound6.setRoundBottomRight(30);
        panelRound6.setRoundTopLeft(30);
        panelRound6.setRoundTopRight(30);

        jLabel11.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(255, 255, 255));
        jLabel11.setText("General fitness");

        javax.swing.GroupLayout panelRound6Layout = new javax.swing.GroupLayout(panelRound6);
        panelRound6.setLayout(panelRound6Layout);
        panelRound6Layout.setHorizontalGroup(
            panelRound6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 236, Short.MAX_VALUE)
            .addGroup(panelRound6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(panelRound6Layout.createSequentialGroup()
                    .addGap(0, 72, Short.MAX_VALUE)
                    .addComponent(jLabel11)
                    .addGap(0, 73, Short.MAX_VALUE)))
        );
        panelRound6Layout.setVerticalGroup(
            panelRound6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 67, Short.MAX_VALUE)
            .addGroup(panelRound6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(panelRound6Layout.createSequentialGroup()
                    .addGap(0, 23, Short.MAX_VALUE)
                    .addComponent(jLabel11)
                    .addGap(0, 24, Short.MAX_VALUE)))
        );

        panelRound1.add(panelRound6);

        panelRound7.setBackground(new java.awt.Color(255, 144, 69));
        panelRound7.setRoundBottomLeft(30);
        panelRound7.setRoundBottomRight(30);
        panelRound7.setRoundTopLeft(30);
        panelRound7.setRoundTopRight(30);

        jLabel6.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("Women's fitness");

        javax.swing.GroupLayout panelRound7Layout = new javax.swing.GroupLayout(panelRound7);
        panelRound7.setLayout(panelRound7Layout);
        panelRound7Layout.setHorizontalGroup(
            panelRound7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 236, Short.MAX_VALUE)
            .addGroup(panelRound7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(panelRound7Layout.createSequentialGroup()
                    .addGap(0, 67, Short.MAX_VALUE)
                    .addComponent(jLabel6)
                    .addGap(0, 67, Short.MAX_VALUE)))
        );
        panelRound7Layout.setVerticalGroup(
            panelRound7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 67, Short.MAX_VALUE)
            .addGroup(panelRound7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(panelRound7Layout.createSequentialGroup()
                    .addGap(0, 23, Short.MAX_VALUE)
                    .addComponent(jLabel6)
                    .addGap(0, 24, Short.MAX_VALUE)))
        );

        panelRound1.add(panelRound7);

        panelRound8.setBackground(new java.awt.Color(255, 144, 69));
        panelRound8.setRoundBottomLeft(30);
        panelRound8.setRoundBottomRight(30);
        panelRound8.setRoundTopLeft(30);
        panelRound8.setRoundTopRight(30);

        jLabel12.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(255, 255, 255));
        jLabel12.setText("Family fitness");

        javax.swing.GroupLayout panelRound8Layout = new javax.swing.GroupLayout(panelRound8);
        panelRound8.setLayout(panelRound8Layout);
        panelRound8Layout.setHorizontalGroup(
            panelRound8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 236, Short.MAX_VALUE)
            .addGroup(panelRound8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(panelRound8Layout.createSequentialGroup()
                    .addGap(0, 76, Short.MAX_VALUE)
                    .addComponent(jLabel12)
                    .addGap(0, 77, Short.MAX_VALUE)))
        );
        panelRound8Layout.setVerticalGroup(
            panelRound8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 67, Short.MAX_VALUE)
            .addGroup(panelRound8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(panelRound8Layout.createSequentialGroup()
                    .addGap(0, 23, Short.MAX_VALUE)
                    .addComponent(jLabel12)
                    .addGap(0, 24, Short.MAX_VALUE)))
        );

        panelRound1.add(panelRound8);

        panelRound9.setBackground(new java.awt.Color(255, 144, 69));
        panelRound9.setRoundBottomLeft(30);
        panelRound9.setRoundBottomRight(30);
        panelRound9.setRoundTopLeft(30);
        panelRound9.setRoundTopRight(30);

        jLabel7.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("Group exercise programs");

        javax.swing.GroupLayout panelRound9Layout = new javax.swing.GroupLayout(panelRound9);
        panelRound9.setLayout(panelRound9Layout);
        panelRound9Layout.setHorizontalGroup(
            panelRound9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 236, Short.MAX_VALUE)
            .addGroup(panelRound9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(panelRound9Layout.createSequentialGroup()
                    .addGap(0, 41, Short.MAX_VALUE)
                    .addComponent(jLabel7)
                    .addGap(0, 41, Short.MAX_VALUE)))
        );
        panelRound9Layout.setVerticalGroup(
            panelRound9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 67, Short.MAX_VALUE)
            .addGroup(panelRound9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(panelRound9Layout.createSequentialGroup()
                    .addGap(0, 23, Short.MAX_VALUE)
                    .addComponent(jLabel7)
                    .addGap(0, 24, Short.MAX_VALUE)))
        );

        panelRound1.add(panelRound9);

        panelRound10.setBackground(new java.awt.Color(255, 144, 69));
        panelRound10.setRoundBottomLeft(30);
        panelRound10.setRoundBottomRight(30);
        panelRound10.setRoundTopLeft(30);
        panelRound10.setRoundTopRight(30);

        jLabel13.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(255, 255, 255));
        jLabel13.setText("Sport-specific training");

        javax.swing.GroupLayout panelRound10Layout = new javax.swing.GroupLayout(panelRound10);
        panelRound10.setLayout(panelRound10Layout);
        panelRound10Layout.setHorizontalGroup(
            panelRound10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 236, Short.MAX_VALUE)
            .addGroup(panelRound10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(panelRound10Layout.createSequentialGroup()
                    .addGap(0, 51, Short.MAX_VALUE)
                    .addComponent(jLabel13)
                    .addGap(0, 50, Short.MAX_VALUE)))
        );
        panelRound10Layout.setVerticalGroup(
            panelRound10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 67, Short.MAX_VALUE)
            .addGroup(panelRound10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(panelRound10Layout.createSequentialGroup()
                    .addGap(0, 23, Short.MAX_VALUE)
                    .addComponent(jLabel13)
                    .addGap(0, 24, Short.MAX_VALUE)))
        );

        panelRound1.add(panelRound10);

        panelRound11.setBackground(new java.awt.Color(255, 144, 69));
        panelRound11.setRoundBottomLeft(30);
        panelRound11.setRoundBottomRight(30);
        panelRound11.setRoundTopLeft(30);
        panelRound11.setRoundTopRight(30);

        jLabel8.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("Weight Loss");

        javax.swing.GroupLayout panelRound11Layout = new javax.swing.GroupLayout(panelRound11);
        panelRound11.setLayout(panelRound11Layout);
        panelRound11Layout.setHorizontalGroup(
            panelRound11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 236, Short.MAX_VALUE)
            .addGroup(panelRound11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(panelRound11Layout.createSequentialGroup()
                    .addGap(0, 80, Short.MAX_VALUE)
                    .addComponent(jLabel8)
                    .addGap(0, 81, Short.MAX_VALUE)))
        );
        panelRound11Layout.setVerticalGroup(
            panelRound11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 67, Short.MAX_VALUE)
            .addGroup(panelRound11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(panelRound11Layout.createSequentialGroup()
                    .addGap(0, 23, Short.MAX_VALUE)
                    .addComponent(jLabel8)
                    .addGap(0, 24, Short.MAX_VALUE)))
        );

        panelRound1.add(panelRound11);

        panelRound12.setBackground(new java.awt.Color(255, 144, 69));
        panelRound12.setRoundBottomLeft(30);
        panelRound12.setRoundBottomRight(30);
        panelRound12.setRoundTopLeft(30);
        panelRound12.setRoundTopRight(30);

        jLabel14.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(255, 255, 255));
        jLabel14.setText("Children and teens fitness");

        javax.swing.GroupLayout panelRound12Layout = new javax.swing.GroupLayout(panelRound12);
        panelRound12.setLayout(panelRound12Layout);
        panelRound12Layout.setHorizontalGroup(
            panelRound12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 236, Short.MAX_VALUE)
            .addGroup(panelRound12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(panelRound12Layout.createSequentialGroup()
                    .addGap(0, 38, Short.MAX_VALUE)
                    .addComponent(jLabel14)
                    .addGap(0, 38, Short.MAX_VALUE)))
        );
        panelRound12Layout.setVerticalGroup(
            panelRound12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 67, Short.MAX_VALUE)
            .addGroup(panelRound12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(panelRound12Layout.createSequentialGroup()
                    .addGap(0, 23, Short.MAX_VALUE)
                    .addComponent(jLabel14)
                    .addGap(0, 24, Short.MAX_VALUE)))
        );

        panelRound1.add(panelRound12);

        panelRound13.setBackground(new java.awt.Color(255, 144, 69));
        panelRound13.setRoundBottomLeft(30);
        panelRound13.setRoundBottomRight(30);
        panelRound13.setRoundTopLeft(30);
        panelRound13.setRoundTopRight(30);

        jLabel9.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setText("Body-fat reduction");

        javax.swing.GroupLayout panelRound13Layout = new javax.swing.GroupLayout(panelRound13);
        panelRound13.setLayout(panelRound13Layout);
        panelRound13Layout.setHorizontalGroup(
            panelRound13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 236, Short.MAX_VALUE)
            .addGroup(panelRound13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(panelRound13Layout.createSequentialGroup()
                    .addGap(0, 60, Short.MAX_VALUE)
                    .addComponent(jLabel9)
                    .addGap(0, 61, Short.MAX_VALUE)))
        );
        panelRound13Layout.setVerticalGroup(
            panelRound13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 67, Short.MAX_VALUE)
            .addGroup(panelRound13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(panelRound13Layout.createSequentialGroup()
                    .addGap(0, 23, Short.MAX_VALUE)
                    .addComponent(jLabel9)
                    .addGap(0, 24, Short.MAX_VALUE)))
        );

        panelRound1.add(panelRound13);

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Personal Fitness Programs");

        panelRound14.setBackground(new java.awt.Color(16, 16, 16));
        panelRound14.setRoundBottomLeft(30);
        panelRound14.setRoundBottomRight(30);
        panelRound14.setRoundTopLeft(30);
        panelRound14.setRoundTopRight(30);

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/FitnessManager/images/dumbell_1_-removebg-preview.png"))); // NOI18N

        jLabel16.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel16.setForeground(new java.awt.Color(255, 255, 255));
        jLabel16.setText("Staff Name");

        jLabel17.setBackground(new java.awt.Color(153, 153, 153));
        jLabel17.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel17.setForeground(new java.awt.Color(255, 144, 69));
        jLabel17.setText("Assistant Manager");

        jPanel3.setBackground(new java.awt.Color(0, 0, 0));
        jPanel3.setLayout(new java.awt.GridLayout(1, 3, 5, 0));

        panelRound16.setBackground(new java.awt.Color(49, 255, 178));
        panelRound16.setRoundBottomLeft(30);
        panelRound16.setRoundBottomRight(30);
        panelRound16.setRoundTopLeft(30);
        panelRound16.setRoundTopRight(30);

        jLabel19.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel19.setText("ID");

        jLabel22.setText("EMP");

        javax.swing.GroupLayout panelRound16Layout = new javax.swing.GroupLayout(panelRound16);
        panelRound16.setLayout(panelRound16Layout);
        panelRound16Layout.setHorizontalGroup(
            panelRound16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelRound16Layout.createSequentialGroup()
                .addContainerGap(48, Short.MAX_VALUE)
                .addGroup(panelRound16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel22)
                    .addComponent(jLabel19))
                .addGap(47, 47, 47))
        );
        panelRound16Layout.setVerticalGroup(
            panelRound16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelRound16Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel19)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel22)
                .addContainerGap(18, Short.MAX_VALUE))
        );

        jPanel3.add(panelRound16);

        panelRound17.setBackground(new java.awt.Color(49, 255, 178));
        panelRound17.setRoundBottomLeft(30);
        panelRound17.setRoundBottomRight(30);
        panelRound17.setRoundTopLeft(30);
        panelRound17.setRoundTopRight(30);

        jLabel20.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel20.setText("Experience");

        jLabel23.setText("20 years");

        javax.swing.GroupLayout panelRound17Layout = new javax.swing.GroupLayout(panelRound17);
        panelRound17.setLayout(panelRound17Layout);
        panelRound17Layout.setHorizontalGroup(
            panelRound17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelRound17Layout.createSequentialGroup()
                .addGroup(panelRound17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panelRound17Layout.createSequentialGroup()
                        .addGap(21, 21, 21)
                        .addComponent(jLabel20))
                    .addGroup(panelRound17Layout.createSequentialGroup()
                        .addGap(36, 36, 36)
                        .addComponent(jLabel23)))
                .addContainerGap(26, Short.MAX_VALUE))
        );
        panelRound17Layout.setVerticalGroup(
            panelRound17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelRound17Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel20)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel23)
                .addContainerGap(18, Short.MAX_VALUE))
        );

        jPanel3.add(panelRound17);

        panelRound15.setBackground(new java.awt.Color(49, 255, 178));
        panelRound15.setRoundBottomLeft(30);
        panelRound15.setRoundBottomRight(30);
        panelRound15.setRoundTopLeft(30);
        panelRound15.setRoundTopRight(30);

        jLabel21.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel21.setText("Position");

        jLabel24.setText("Manager");

        javax.swing.GroupLayout panelRound15Layout = new javax.swing.GroupLayout(panelRound15);
        panelRound15.setLayout(panelRound15Layout);
        panelRound15Layout.setHorizontalGroup(
            panelRound15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelRound15Layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addComponent(jLabel21)
                .addContainerGap(34, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelRound15Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel24)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        panelRound15Layout.setVerticalGroup(
            panelRound15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelRound15Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel21)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel24)
                .addContainerGap(18, Short.MAX_VALUE))
        );

        jPanel3.add(panelRound15);

        jCalendar1.setDecorationBackgroundColor(new java.awt.Color(49, 228, 178));

        javax.swing.GroupLayout panelRound14Layout = new javax.swing.GroupLayout(panelRound14);
        panelRound14.setLayout(panelRound14Layout);
        panelRound14Layout.setHorizontalGroup(
            panelRound14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelRound14Layout.createSequentialGroup()
                .addGap(50, 50, 50)
                .addGroup(panelRound14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(jCalendar1, javax.swing.GroupLayout.PREFERRED_SIZE, 365, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, 365, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(panelRound14Layout.createSequentialGroup()
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(28, 28, 28)
                        .addGroup(panelRound14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel17, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel16, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addGap(65, 65, 65))
        );
        panelRound14Layout.setVerticalGroup(
            panelRound14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelRound14Layout.createSequentialGroup()
                .addGroup(panelRound14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panelRound14Layout.createSequentialGroup()
                        .addGap(46, 46, 46)
                        .addComponent(jLabel16)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel17))
                    .addGroup(panelRound14Layout.createSequentialGroup()
                        .addGap(26, 26, 26)
                        .addComponent(jLabel1)))
                .addGap(18, 18, 18)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jCalendar1, javax.swing.GroupLayout.PREFERRED_SIZE, 197, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jLabel15.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(255, 255, 255));
        jLabel15.setText("Profile");

        javax.swing.GroupLayout DashboardLayout = new javax.swing.GroupLayout(Dashboard);
        Dashboard.setLayout(DashboardLayout);
        DashboardLayout.setHorizontalGroup(
            DashboardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(DashboardLayout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addGroup(DashboardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(panelRound1, javax.swing.GroupLayout.PREFERRED_SIZE, 475, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(12, 12, 12)
                .addGroup(DashboardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(panelRound14, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(1280, Short.MAX_VALUE))
        );
        DashboardLayout.setVerticalGroup(
            DashboardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(DashboardLayout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addGroup(DashboardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(jLabel15))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(DashboardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(panelRound14, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(panelRound1, javax.swing.GroupLayout.DEFAULT_SIZE, 418, Short.MAX_VALUE))
                .addContainerGap(63, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("tab1", Dashboard);

        Books.setBackground(new java.awt.Color(0, 0, 0));

        jLabel31.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel31.setForeground(new java.awt.Color(255, 255, 255));
        jLabel31.setText("Books");

        panelRound21.setRoundBottomLeft(30);
        panelRound21.setRoundBottomRight(30);
        panelRound21.setRoundTopLeft(30);
        panelRound21.setRoundTopRight(30);

        jPanel5.setLayout(new java.awt.GridLayout(4, 2, 5, 5));

        jLabel32.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel32.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel32.setText("Book ID");
        jPanel5.add(jLabel32);
        jPanel5.add(bookID);

        jLabel33.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel33.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel33.setText("Name");
        jPanel5.add(jLabel33);

        name.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nameActionPerformed(evt);
            }
        });
        jPanel5.add(name);

        jLabel34.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel34.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel34.setText("Price ($)");
        jPanel5.add(jLabel34);
        jPanel5.add(price);

        jLabel35.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel35.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel35.setText("Quantity");
        jPanel5.add(jLabel35);
        jPanel5.add(quantity);

        javax.swing.GroupLayout panelRound21Layout = new javax.swing.GroupLayout(panelRound21);
        panelRound21.setLayout(panelRound21Layout);
        panelRound21Layout.setHorizontalGroup(
            panelRound21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelRound21Layout.createSequentialGroup()
                .addGap(209, 209, 209)
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, 436, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(213, Short.MAX_VALUE))
        );
        panelRound21Layout.setVerticalGroup(
            panelRound21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelRound21Layout.createSequentialGroup()
                .addGap(34, 34, 34)
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(43, Short.MAX_VALUE))
        );

        panelRound22.setRoundBottomLeft(30);
        panelRound22.setRoundBottomRight(30);
        panelRound22.setRoundTopLeft(30);
        panelRound22.setRoundTopRight(30);

        BookDetails.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Book  ID", "Name", "Price ($)", "Quantity"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.Double.class, java.lang.Integer.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        BookDetails.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                BookDetailsFocusGained(evt);
            }
        });
        BookDetails.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                BookDetailsMousePressed(evt);
            }
        });
        jScrollPane2.setViewportView(BookDetails);

        javax.swing.GroupLayout panelRound22Layout = new javax.swing.GroupLayout(panelRound22);
        panelRound22.setLayout(panelRound22Layout);
        panelRound22Layout.setHorizontalGroup(
            panelRound22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelRound22Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 846, Short.MAX_VALUE)
                .addContainerGap())
        );
        panelRound22Layout.setVerticalGroup(
            panelRound22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelRound22Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 259, Short.MAX_VALUE)
                .addContainerGap())
        );

        panelRound23.setBackground(new java.awt.Color(0, 0, 0));
        panelRound23.setRoundBottomLeft(30);
        panelRound23.setRoundBottomRight(30);
        panelRound23.setRoundTopLeft(30);
        panelRound23.setRoundTopRight(30);
        panelRound23.setLayout(new java.awt.GridLayout(5, 1, 0, 10));

        addbookbtn.setBackground(new java.awt.Color(255, 144, 69));
        addbookbtn.setRoundBottomLeft(30);
        addbookbtn.setRoundBottomRight(30);
        addbookbtn.setRoundTopLeft(30);
        addbookbtn.setRoundTopRight(30);
        addbookbtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                addbookbtnMousePressed(evt);
            }
        });

        jLabel36.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel36.setForeground(new java.awt.Color(255, 255, 255));
        jLabel36.setText("Add Book");

        javax.swing.GroupLayout addbookbtnLayout = new javax.swing.GroupLayout(addbookbtn);
        addbookbtn.setLayout(addbookbtnLayout);
        addbookbtnLayout.setHorizontalGroup(
            addbookbtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 147, Short.MAX_VALUE)
            .addGroup(addbookbtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(addbookbtnLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jLabel36)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        addbookbtnLayout.setVerticalGroup(
            addbookbtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 85, Short.MAX_VALUE)
            .addGroup(addbookbtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(addbookbtnLayout.createSequentialGroup()
                    .addGap(0, 30, Short.MAX_VALUE)
                    .addComponent(jLabel36)
                    .addGap(0, 30, Short.MAX_VALUE)))
        );

        panelRound23.add(addbookbtn);

        updatebookbtn.setBackground(new java.awt.Color(255, 144, 69));
        updatebookbtn.setRoundBottomLeft(30);
        updatebookbtn.setRoundBottomRight(30);
        updatebookbtn.setRoundTopLeft(30);
        updatebookbtn.setRoundTopRight(30);
        updatebookbtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                updatebookbtnMousePressed(evt);
            }
        });

        jLabel37.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel37.setForeground(new java.awt.Color(255, 255, 255));
        jLabel37.setText("Update Info");

        javax.swing.GroupLayout updatebookbtnLayout = new javax.swing.GroupLayout(updatebookbtn);
        updatebookbtn.setLayout(updatebookbtnLayout);
        updatebookbtnLayout.setHorizontalGroup(
            updatebookbtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 147, Short.MAX_VALUE)
            .addGroup(updatebookbtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(updatebookbtnLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jLabel37)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        updatebookbtnLayout.setVerticalGroup(
            updatebookbtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 85, Short.MAX_VALUE)
            .addGroup(updatebookbtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(updatebookbtnLayout.createSequentialGroup()
                    .addGap(0, 30, Short.MAX_VALUE)
                    .addComponent(jLabel37)
                    .addGap(0, 30, Short.MAX_VALUE)))
        );

        panelRound23.add(updatebookbtn);

        deletebookbtn.setBackground(new java.awt.Color(255, 144, 69));
        deletebookbtn.setRoundBottomLeft(30);
        deletebookbtn.setRoundBottomRight(30);
        deletebookbtn.setRoundTopLeft(30);
        deletebookbtn.setRoundTopRight(30);
        deletebookbtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                deletebookbtnMouseEntered(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                deletebookbtnMousePressed(evt);
            }
        });

        jLabel38.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel38.setForeground(new java.awt.Color(255, 255, 255));
        jLabel38.setText("Delete Book");

        javax.swing.GroupLayout deletebookbtnLayout = new javax.swing.GroupLayout(deletebookbtn);
        deletebookbtn.setLayout(deletebookbtnLayout);
        deletebookbtnLayout.setHorizontalGroup(
            deletebookbtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 147, Short.MAX_VALUE)
            .addGroup(deletebookbtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(deletebookbtnLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jLabel38)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        deletebookbtnLayout.setVerticalGroup(
            deletebookbtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 85, Short.MAX_VALUE)
            .addGroup(deletebookbtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(deletebookbtnLayout.createSequentialGroup()
                    .addGap(0, 30, Short.MAX_VALUE)
                    .addComponent(jLabel38)
                    .addGap(0, 30, Short.MAX_VALUE)))
        );

        panelRound23.add(deletebookbtn);

        resetbookbtn.setBackground(new java.awt.Color(255, 144, 69));
        resetbookbtn.setRoundBottomLeft(30);
        resetbookbtn.setRoundBottomRight(30);
        resetbookbtn.setRoundTopLeft(30);
        resetbookbtn.setRoundTopRight(30);
        resetbookbtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                resetbookbtnMousePressed(evt);
            }
        });

        jLabel39.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel39.setForeground(new java.awt.Color(255, 255, 255));
        jLabel39.setText("Reset");

        javax.swing.GroupLayout resetbookbtnLayout = new javax.swing.GroupLayout(resetbookbtn);
        resetbookbtn.setLayout(resetbookbtnLayout);
        resetbookbtnLayout.setHorizontalGroup(
            resetbookbtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 147, Short.MAX_VALUE)
            .addGroup(resetbookbtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(resetbookbtnLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jLabel39)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        resetbookbtnLayout.setVerticalGroup(
            resetbookbtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 85, Short.MAX_VALUE)
            .addGroup(resetbookbtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(resetbookbtnLayout.createSequentialGroup()
                    .addGap(0, 30, Short.MAX_VALUE)
                    .addComponent(jLabel39)
                    .addGap(0, 30, Short.MAX_VALUE)))
        );

        panelRound23.add(resetbookbtn);

        viewData.setBackground(new java.awt.Color(255, 144, 69));
        viewData.setRoundBottomLeft(30);
        viewData.setRoundBottomRight(30);
        viewData.setRoundTopLeft(30);
        viewData.setRoundTopRight(30);
        viewData.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                viewDataMousePressed(evt);
            }
        });

        jLabel40.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel40.setForeground(new java.awt.Color(255, 255, 255));
        jLabel40.setText("View Data");

        javax.swing.GroupLayout viewDataLayout = new javax.swing.GroupLayout(viewData);
        viewData.setLayout(viewDataLayout);
        viewDataLayout.setHorizontalGroup(
            viewDataLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 147, Short.MAX_VALUE)
            .addGroup(viewDataLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(viewDataLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jLabel40)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        viewDataLayout.setVerticalGroup(
            viewDataLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 85, Short.MAX_VALUE)
            .addGroup(viewDataLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(viewDataLayout.createSequentialGroup()
                    .addGap(0, 30, Short.MAX_VALUE)
                    .addComponent(jLabel40)
                    .addGap(0, 30, Short.MAX_VALUE)))
        );

        panelRound23.add(viewData);

        javax.swing.GroupLayout BooksLayout = new javax.swing.GroupLayout(Books);
        Books.setLayout(BooksLayout);
        BooksLayout.setHorizontalGroup(
            BooksLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(BooksLayout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addGroup(BooksLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel31)
                    .addComponent(panelRound21, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(panelRound22, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(panelRound23, javax.swing.GroupLayout.PREFERRED_SIZE, 147, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(1236, Short.MAX_VALUE))
        );
        BooksLayout.setVerticalGroup(
            BooksLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(BooksLayout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addComponent(jLabel31)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(BooksLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(BooksLayout.createSequentialGroup()
                        .addComponent(panelRound21, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(panelRound22, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(panelRound23, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(12, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("tab3", Books);

        Employee.setBackground(new java.awt.Color(0, 0, 0));

        jLabel42.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel42.setForeground(new java.awt.Color(255, 255, 255));
        jLabel42.setText("Employees");

        panelRound24.setRoundBottomLeft(30);
        panelRound24.setRoundBottomRight(30);
        panelRound24.setRoundTopLeft(30);
        panelRound24.setRoundTopRight(30);

        jPanel6.setLayout(new java.awt.GridLayout(6, 2, 5, 5));

        jLabel43.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel43.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel43.setText("EmployeeID");
        jPanel6.add(jLabel43);
        jPanel6.add(employeeID);

        jLabel44.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel44.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel44.setText("First Name");
        jPanel6.add(jLabel44);
        jPanel6.add(empFirstName);

        jLabel45.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel45.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel45.setText("Last Name");
        jPanel6.add(jLabel45);
        jPanel6.add(empLastName);

        jLabel53.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel53.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel53.setText("Email");
        jPanel6.add(jLabel53);

        empEmail.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                empEmailActionPerformed(evt);
            }
        });
        jPanel6.add(empEmail);

        jLabel46.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel46.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel46.setText("Course ");
        jPanel6.add(jLabel46);

        course_tutoring.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "One-on-one personal training", "Physical fitness", "Women's fitness", "Group exercise programs", "Weight loss", "Body-fat reduction", "Muscle toning", "General fitness", "Family fitness", "Sport-specific training", "Children and teens fitness" }));
        jPanel6.add(course_tutoring);

        jLabel47.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel47.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel47.setText("Position");
        jPanel6.add(jLabel47);

        position.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Trainer", "Assistant Trainer", "Assistant Manager" }));
        jPanel6.add(position);

        javax.swing.GroupLayout panelRound24Layout = new javax.swing.GroupLayout(panelRound24);
        panelRound24.setLayout(panelRound24Layout);
        panelRound24Layout.setHorizontalGroup(
            panelRound24Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 825, Short.MAX_VALUE)
            .addGroup(panelRound24Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelRound24Layout.createSequentialGroup()
                    .addContainerGap(173, Short.MAX_VALUE)
                    .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, 482, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(170, Short.MAX_VALUE)))
        );
        panelRound24Layout.setVerticalGroup(
            panelRound24Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 204, Short.MAX_VALUE)
            .addGroup(panelRound24Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelRound24Layout.createSequentialGroup()
                    .addContainerGap(20, Short.MAX_VALUE)
                    .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(20, Short.MAX_VALUE)))
        );

        panelRound25.setRoundBottomLeft(30);
        panelRound25.setRoundBottomRight(30);
        panelRound25.setRoundTopLeft(30);
        panelRound25.setRoundTopRight(30);

        EmployeeTable.setBackground(new java.awt.Color(49, 255, 178));
        EmployeeTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "EmployeeID", "First Name", "Last Name", "Email", "Course", "Position"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        EmployeeTable.setRowHeight(40);
        EmployeeTable.setRowMargin(10);
        EmployeeTable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                EmployeeTableMousePressed(evt);
            }
        });
        jScrollPane3.setViewportView(EmployeeTable);

        javax.swing.GroupLayout panelRound25Layout = new javax.swing.GroupLayout(panelRound25);
        panelRound25.setLayout(panelRound25Layout);
        panelRound25Layout.setHorizontalGroup(
            panelRound25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelRound25Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane3)
                .addContainerGap())
        );
        panelRound25Layout.setVerticalGroup(
            panelRound25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelRound25Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 216, Short.MAX_VALUE)
                .addContainerGap())
        );

        panelRound27.setBackground(new java.awt.Color(0, 0, 0));
        panelRound27.setRoundBottomLeft(30);
        panelRound27.setRoundBottomRight(30);
        panelRound27.setRoundTopLeft(30);
        panelRound27.setRoundTopRight(30);
        panelRound27.setLayout(new java.awt.GridLayout(5, 1, 0, 10));

        addempbtn.setBackground(new java.awt.Color(255, 144, 69));
        addempbtn.setRoundBottomLeft(30);
        addempbtn.setRoundBottomRight(30);
        addempbtn.setRoundTopLeft(30);
        addempbtn.setRoundTopRight(30);
        addempbtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                addempbtnMousePressed(evt);
            }
        });

        jLabel48.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel48.setForeground(new java.awt.Color(255, 255, 255));
        jLabel48.setText("Add Employee");

        javax.swing.GroupLayout addempbtnLayout = new javax.swing.GroupLayout(addempbtn);
        addempbtn.setLayout(addempbtnLayout);
        addempbtnLayout.setHorizontalGroup(
            addempbtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 145, Short.MAX_VALUE)
            .addGroup(addempbtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(addempbtnLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jLabel48)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        addempbtnLayout.setVerticalGroup(
            addempbtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 79, Short.MAX_VALUE)
            .addGroup(addempbtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(addempbtnLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jLabel48)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );

        panelRound27.add(addempbtn);

        updateempbtn.setBackground(new java.awt.Color(255, 144, 69));
        updateempbtn.setRoundBottomLeft(30);
        updateempbtn.setRoundBottomRight(30);
        updateempbtn.setRoundTopLeft(30);
        updateempbtn.setRoundTopRight(30);
        updateempbtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                updateempbtnMousePressed(evt);
            }
        });

        jLabel49.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel49.setForeground(new java.awt.Color(255, 255, 255));
        jLabel49.setText("Update Info");

        javax.swing.GroupLayout updateempbtnLayout = new javax.swing.GroupLayout(updateempbtn);
        updateempbtn.setLayout(updateempbtnLayout);
        updateempbtnLayout.setHorizontalGroup(
            updateempbtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 145, Short.MAX_VALUE)
            .addGroup(updateempbtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(updateempbtnLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jLabel49)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        updateempbtnLayout.setVerticalGroup(
            updateempbtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 79, Short.MAX_VALUE)
            .addGroup(updateempbtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(updateempbtnLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jLabel49)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );

        panelRound27.add(updateempbtn);

        deleteempbtn.setBackground(new java.awt.Color(255, 144, 69));
        deleteempbtn.setRoundBottomLeft(30);
        deleteempbtn.setRoundBottomRight(30);
        deleteempbtn.setRoundTopLeft(30);
        deleteempbtn.setRoundTopRight(30);
        deleteempbtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                deleteempbtnMousePressed(evt);
            }
        });

        jLabel50.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel50.setForeground(new java.awt.Color(255, 255, 255));
        jLabel50.setText("Delete Employee");

        javax.swing.GroupLayout deleteempbtnLayout = new javax.swing.GroupLayout(deleteempbtn);
        deleteempbtn.setLayout(deleteempbtnLayout);
        deleteempbtnLayout.setHorizontalGroup(
            deleteempbtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 145, Short.MAX_VALUE)
            .addGroup(deleteempbtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(deleteempbtnLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jLabel50)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        deleteempbtnLayout.setVerticalGroup(
            deleteempbtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 79, Short.MAX_VALUE)
            .addGroup(deleteempbtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(deleteempbtnLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jLabel50)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );

        panelRound27.add(deleteempbtn);

        resetempbtn.setBackground(new java.awt.Color(255, 144, 69));
        resetempbtn.setRoundBottomLeft(30);
        resetempbtn.setRoundBottomRight(30);
        resetempbtn.setRoundTopLeft(30);
        resetempbtn.setRoundTopRight(30);
        resetempbtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                resetempbtnMousePressed(evt);
            }
        });

        jLabel51.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel51.setForeground(new java.awt.Color(255, 255, 255));
        jLabel51.setText("Reset");

        javax.swing.GroupLayout resetempbtnLayout = new javax.swing.GroupLayout(resetempbtn);
        resetempbtn.setLayout(resetempbtnLayout);
        resetempbtnLayout.setHorizontalGroup(
            resetempbtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 145, Short.MAX_VALUE)
            .addGroup(resetempbtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(resetempbtnLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jLabel51)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        resetempbtnLayout.setVerticalGroup(
            resetempbtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 79, Short.MAX_VALUE)
            .addGroup(resetempbtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(resetempbtnLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jLabel51)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );

        panelRound27.add(resetempbtn);

        viewEmpDatabtn.setBackground(new java.awt.Color(255, 144, 69));
        viewEmpDatabtn.setRoundBottomLeft(30);
        viewEmpDatabtn.setRoundBottomRight(30);
        viewEmpDatabtn.setRoundTopLeft(30);
        viewEmpDatabtn.setRoundTopRight(30);
        viewEmpDatabtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                viewEmpDatabtnMousePressed(evt);
            }
        });

        jLabel52.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel52.setForeground(new java.awt.Color(255, 255, 255));
        jLabel52.setText("View Data");

        javax.swing.GroupLayout viewEmpDatabtnLayout = new javax.swing.GroupLayout(viewEmpDatabtn);
        viewEmpDatabtn.setLayout(viewEmpDatabtnLayout);
        viewEmpDatabtnLayout.setHorizontalGroup(
            viewEmpDatabtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 145, Short.MAX_VALUE)
            .addGroup(viewEmpDatabtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(viewEmpDatabtnLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jLabel52)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        viewEmpDatabtnLayout.setVerticalGroup(
            viewEmpDatabtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 79, Short.MAX_VALUE)
            .addGroup(viewEmpDatabtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(viewEmpDatabtnLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jLabel52)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );

        panelRound27.add(viewEmpDatabtn);

        javax.swing.GroupLayout EmployeeLayout = new javax.swing.GroupLayout(Employee);
        Employee.setLayout(EmployeeLayout);
        EmployeeLayout.setHorizontalGroup(
            EmployeeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(EmployeeLayout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addGroup(EmployeeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel42)
                    .addGroup(EmployeeLayout.createSequentialGroup()
                        .addGroup(EmployeeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(panelRound24, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(panelRound25, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(panelRound27, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(1271, Short.MAX_VALUE))
        );
        EmployeeLayout.setVerticalGroup(
            EmployeeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(EmployeeLayout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addComponent(jLabel42)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(EmployeeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(EmployeeLayout.createSequentialGroup()
                        .addComponent(panelRound24, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(panelRound25, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(panelRound27, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(16, 16, 16))
        );

        jTabbedPane1.addTab("tab5", Employee);

        Enquiries.setBackground(new java.awt.Color(0, 0, 0));

        jLabel54.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel54.setForeground(new java.awt.Color(255, 255, 255));
        jLabel54.setText("Enquiries");

        panelRound26.setRoundBottomLeft(30);
        panelRound26.setRoundBottomRight(30);
        panelRound26.setRoundTopLeft(30);
        panelRound26.setRoundTopRight(30);

        EnquiryTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Enquiry ID", "Category", "Description", "Customer Email", "Enquiry Date"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        EnquiryTable.setOpaque(false);
        EnquiryTable.setRowHeight(40);
        EnquiryTable.setRowMargin(10);
        jScrollPane4.setViewportView(EnquiryTable);

        javax.swing.GroupLayout panelRound26Layout = new javax.swing.GroupLayout(panelRound26);
        panelRound26.setLayout(panelRound26Layout);
        panelRound26Layout.setHorizontalGroup(
            panelRound26Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 947, Short.MAX_VALUE)
            .addGroup(panelRound26Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(panelRound26Layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(jScrollPane4, javax.swing.GroupLayout.DEFAULT_SIZE, 935, Short.MAX_VALUE)
                    .addContainerGap()))
        );
        panelRound26Layout.setVerticalGroup(
            panelRound26Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 407, Short.MAX_VALUE)
            .addGroup(panelRound26Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelRound26Layout.createSequentialGroup()
                    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 395, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap()))
        );

        viewEnqDatabtn.setBackground(new java.awt.Color(255, 144, 69));
        viewEnqDatabtn.setRoundBottomLeft(30);
        viewEnqDatabtn.setRoundBottomRight(30);
        viewEnqDatabtn.setRoundTopLeft(30);
        viewEnqDatabtn.setRoundTopRight(30);
        viewEnqDatabtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                viewEnqDatabtnMousePressed(evt);
            }
        });

        jLabel55.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel55.setForeground(new java.awt.Color(255, 255, 255));
        jLabel55.setText("View Data");

        javax.swing.GroupLayout viewEnqDatabtnLayout = new javax.swing.GroupLayout(viewEnqDatabtn);
        viewEnqDatabtn.setLayout(viewEnqDatabtnLayout);
        viewEnqDatabtnLayout.setHorizontalGroup(
            viewEnqDatabtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
            .addGroup(viewEnqDatabtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(viewEnqDatabtnLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jLabel55)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        viewEnqDatabtnLayout.setVerticalGroup(
            viewEnqDatabtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 70, Short.MAX_VALUE)
            .addGroup(viewEnqDatabtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(viewEnqDatabtnLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jLabel55)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );

        javax.swing.GroupLayout EnquiriesLayout = new javax.swing.GroupLayout(Enquiries);
        Enquiries.setLayout(EnquiriesLayout);
        EnquiriesLayout.setHorizontalGroup(
            EnquiriesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(EnquiriesLayout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addGroup(EnquiriesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel54)
                    .addComponent(panelRound26, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(viewEnqDatabtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(508, 508, 508))
        );
        EnquiriesLayout.setVerticalGroup(
            EnquiriesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(EnquiriesLayout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addComponent(jLabel54)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(panelRound26, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(viewEnqDatabtn, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("tab2", Enquiries);

        Admission.setBackground(new java.awt.Color(0, 0, 0));
        Admission.setPreferredSize(new java.awt.Dimension(1072, 485));

        panelRound4.setPreferredSize(new java.awt.Dimension(680, 357));
        panelRound4.setRoundBottomLeft(30);
        panelRound4.setRoundBottomRight(30);
        panelRound4.setRoundTopLeft(30);
        panelRound4.setRoundTopRight(30);

        jScrollPane1.setBorder(null);

        CustomerAdmission.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "CustomerID", "First Name", "Last Name", "Email", "Batch Number", "Course Registered", "Phone Number", "Payment Method"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.Object.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.Object.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        CustomerAdmission.setRowHeight(40);
        CustomerAdmission.setRowMargin(10);
        CustomerAdmission.setShowGrid(true);
        CustomerAdmission.getTableHeader().setReorderingAllowed(false);
        CustomerAdmission.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                CustomerAdmissionMouseClicked(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                CustomerAdmissionMousePressed(evt);
            }
        });
        jScrollPane1.setViewportView(CustomerAdmission);

        javax.swing.GroupLayout panelRound4Layout = new javax.swing.GroupLayout(panelRound4);
        panelRound4.setLayout(panelRound4Layout);
        panelRound4Layout.setHorizontalGroup(
            panelRound4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelRound4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 967, Short.MAX_VALUE)
                .addContainerGap())
        );
        panelRound4Layout.setVerticalGroup(
            panelRound4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelRound4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 241, Short.MAX_VALUE)
                .addContainerGap())
        );

        jLabel25.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel25.setForeground(new java.awt.Color(255, 255, 255));
        jLabel25.setText("Admission");

        panelRound19.setBackground(new java.awt.Color(0, 0, 0));
        panelRound19.setRoundBottomLeft(30);
        panelRound19.setRoundBottomRight(30);
        panelRound19.setRoundTopLeft(30);
        panelRound19.setRoundTopRight(30);
        panelRound19.setLayout(new java.awt.GridLayout(1, 4, 10, 0));

        adddeetsbtn.setBackground(new java.awt.Color(255, 144, 69));
        adddeetsbtn.setRoundBottomLeft(30);
        adddeetsbtn.setRoundBottomRight(30);
        adddeetsbtn.setRoundTopLeft(30);
        adddeetsbtn.setRoundTopRight(30);
        adddeetsbtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                adddeetsbtnMousePressed(evt);
            }
        });

        jLabel26.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel26.setForeground(new java.awt.Color(255, 255, 255));
        jLabel26.setText("Add CustomerID");

        javax.swing.GroupLayout adddeetsbtnLayout = new javax.swing.GroupLayout(adddeetsbtn);
        adddeetsbtn.setLayout(adddeetsbtnLayout);
        adddeetsbtnLayout.setHorizontalGroup(
            adddeetsbtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(adddeetsbtnLayout.createSequentialGroup()
                .addGap(49, 49, 49)
                .addComponent(jLabel26)
                .addContainerGap(61, Short.MAX_VALUE))
        );
        adddeetsbtnLayout.setVerticalGroup(
            adddeetsbtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, adddeetsbtnLayout.createSequentialGroup()
                .addContainerGap(27, Short.MAX_VALUE)
                .addComponent(jLabel26)
                .addGap(21, 21, 21))
        );

        panelRound19.add(adddeetsbtn);

        updatedeetsbtn.setBackground(new java.awt.Color(255, 144, 69));
        updatedeetsbtn.setRoundBottomLeft(30);
        updatedeetsbtn.setRoundBottomRight(30);
        updatedeetsbtn.setRoundTopLeft(30);
        updatedeetsbtn.setRoundTopRight(30);
        updatedeetsbtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                updatedeetsbtnMousePressed(evt);
            }
        });

        jLabel28.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel28.setForeground(new java.awt.Color(255, 255, 255));
        jLabel28.setText("Update Info");

        javax.swing.GroupLayout updatedeetsbtnLayout = new javax.swing.GroupLayout(updatedeetsbtn);
        updatedeetsbtn.setLayout(updatedeetsbtnLayout);
        updatedeetsbtnLayout.setHorizontalGroup(
            updatedeetsbtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(updatedeetsbtnLayout.createSequentialGroup()
                .addGap(72, 72, 72)
                .addComponent(jLabel28)
                .addContainerGap(74, Short.MAX_VALUE))
        );
        updatedeetsbtnLayout.setVerticalGroup(
            updatedeetsbtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, updatedeetsbtnLayout.createSequentialGroup()
                .addContainerGap(27, Short.MAX_VALUE)
                .addComponent(jLabel28)
                .addGap(21, 21, 21))
        );

        panelRound19.add(updatedeetsbtn);

        viewCustomerDatabtn.setBackground(new java.awt.Color(255, 144, 69));
        viewCustomerDatabtn.setRoundBottomLeft(30);
        viewCustomerDatabtn.setRoundBottomRight(30);
        viewCustomerDatabtn.setRoundTopLeft(30);
        viewCustomerDatabtn.setRoundTopRight(30);
        viewCustomerDatabtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                viewCustomerDatabtnMousePressed(evt);
            }
        });

        jLabel41.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel41.setForeground(new java.awt.Color(255, 255, 255));
        jLabel41.setText("View Data");

        javax.swing.GroupLayout viewCustomerDatabtnLayout = new javax.swing.GroupLayout(viewCustomerDatabtn);
        viewCustomerDatabtn.setLayout(viewCustomerDatabtnLayout);
        viewCustomerDatabtnLayout.setHorizontalGroup(
            viewCustomerDatabtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(viewCustomerDatabtnLayout.createSequentialGroup()
                .addGap(78, 78, 78)
                .addComponent(jLabel41)
                .addContainerGap(82, Short.MAX_VALUE))
        );
        viewCustomerDatabtnLayout.setVerticalGroup(
            viewCustomerDatabtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, viewCustomerDatabtnLayout.createSequentialGroup()
                .addContainerGap(28, Short.MAX_VALUE)
                .addComponent(jLabel41)
                .addGap(20, 20, 20))
        );

        panelRound19.add(viewCustomerDatabtn);

        resetbtn.setBackground(new java.awt.Color(255, 144, 69));
        resetbtn.setRoundBottomLeft(30);
        resetbtn.setRoundBottomRight(30);
        resetbtn.setRoundTopLeft(30);
        resetbtn.setRoundTopRight(30);
        resetbtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                resetbtnMouseClicked(evt);
            }
        });

        jLabel29.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel29.setForeground(new java.awt.Color(255, 255, 255));
        jLabel29.setText("Reset");

        javax.swing.GroupLayout resetbtnLayout = new javax.swing.GroupLayout(resetbtn);
        resetbtn.setLayout(resetbtnLayout);
        resetbtnLayout.setHorizontalGroup(
            resetbtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(resetbtnLayout.createSequentialGroup()
                .addGap(98, 98, 98)
                .addComponent(jLabel29)
                .addContainerGap(98, Short.MAX_VALUE))
        );
        resetbtnLayout.setVerticalGroup(
            resetbtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, resetbtnLayout.createSequentialGroup()
                .addContainerGap(25, Short.MAX_VALUE)
                .addComponent(jLabel29)
                .addGap(23, 23, 23))
        );

        panelRound19.add(resetbtn);

        panelRound20.setRoundBottomLeft(30);
        panelRound20.setRoundBottomRight(30);
        panelRound20.setRoundTopLeft(30);
        panelRound20.setRoundTopRight(30);

        jPanel4.setLayout(new java.awt.GridLayout(1, 2, 5, 5));

        jLabel27.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel27.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel27.setText("CustomerID");
        jPanel4.add(jLabel27);
        jPanel4.add(customerID);

        javax.swing.GroupLayout panelRound20Layout = new javax.swing.GroupLayout(panelRound20);
        panelRound20.setLayout(panelRound20Layout);
        panelRound20Layout.setHorizontalGroup(
            panelRound20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelRound20Layout.createSequentialGroup()
                .addGap(241, 241, 241)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, 473, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        panelRound20Layout.setVerticalGroup(
            panelRound20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelRound20Layout.createSequentialGroup()
                .addGap(46, 46, 46)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(50, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout AdmissionLayout = new javax.swing.GroupLayout(Admission);
        Admission.setLayout(AdmissionLayout);
        AdmissionLayout.setHorizontalGroup(
            AdmissionLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(AdmissionLayout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addGroup(AdmissionLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(panelRound4, javax.swing.GroupLayout.PREFERRED_SIZE, 979, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel25, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(AdmissionLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(panelRound19, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 979, Short.MAX_VALUE)
                        .addComponent(panelRound20, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addContainerGap(1268, Short.MAX_VALUE))
        );
        AdmissionLayout.setVerticalGroup(
            AdmissionLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(AdmissionLayout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addComponent(jLabel25, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(panelRound4, javax.swing.GroupLayout.PREFERRED_SIZE, 253, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(panelRound20, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(panelRound19, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        jTabbedPane1.addTab("tab4", Admission);

        Courses.setBackground(new java.awt.Color(0, 0, 0));

        jLabel61.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel61.setForeground(new java.awt.Color(255, 255, 255));
        jLabel61.setText("Courses");

        panelRound18.setRoundBottomLeft(30);
        panelRound18.setRoundBottomRight(30);
        panelRound18.setRoundTopLeft(30);
        panelRound18.setRoundTopRight(30);

        CourseTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Course ID", "Name", "Fee", "Course Duration (Weeks)"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.Integer.class, java.lang.Integer.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane5.setViewportView(CourseTable);

        javax.swing.GroupLayout panelRound18Layout = new javax.swing.GroupLayout(panelRound18);
        panelRound18.setLayout(panelRound18Layout);
        panelRound18Layout.setHorizontalGroup(
            panelRound18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 901, Short.MAX_VALUE)
            .addGroup(panelRound18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(panelRound18Layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(jScrollPane5, javax.swing.GroupLayout.DEFAULT_SIZE, 889, Short.MAX_VALUE)
                    .addContainerGap()))
        );
        panelRound18Layout.setVerticalGroup(
            panelRound18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
            .addGroup(panelRound18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelRound18Layout.createSequentialGroup()
                    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 395, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
        );

        panelRound28.setBackground(new java.awt.Color(0, 0, 0));
        panelRound28.setLayout(new java.awt.GridLayout(1, 5, 10, 0));

        viewCourseDatabtn.setBackground(new java.awt.Color(255, 144, 69));
        viewCourseDatabtn.setRoundBottomLeft(30);
        viewCourseDatabtn.setRoundBottomRight(30);
        viewCourseDatabtn.setRoundTopLeft(30);
        viewCourseDatabtn.setRoundTopRight(30);
        viewCourseDatabtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                viewCourseDatabtnMousePressed(evt);
            }
        });

        jLabel66.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel66.setForeground(new java.awt.Color(255, 255, 255));
        jLabel66.setText("View Data");

        javax.swing.GroupLayout viewCourseDatabtnLayout = new javax.swing.GroupLayout(viewCourseDatabtn);
        viewCourseDatabtn.setLayout(viewCourseDatabtnLayout);
        viewCourseDatabtnLayout.setHorizontalGroup(
            viewCourseDatabtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
            .addGroup(viewCourseDatabtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(viewCourseDatabtnLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jLabel66)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        viewCourseDatabtnLayout.setVerticalGroup(
            viewCourseDatabtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
            .addGroup(viewCourseDatabtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(viewCourseDatabtnLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jLabel66)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );

        panelRound28.add(viewCourseDatabtn);

        addcoursebtn.setBackground(new java.awt.Color(255, 144, 69));
        addcoursebtn.setRoundBottomLeft(30);
        addcoursebtn.setRoundBottomRight(30);
        addcoursebtn.setRoundTopLeft(30);
        addcoursebtn.setRoundTopRight(30);
        addcoursebtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                addcoursebtnMousePressed(evt);
            }
        });

        jLabel67.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel67.setForeground(new java.awt.Color(255, 255, 255));
        jLabel67.setText("Add New Course");

        javax.swing.GroupLayout addcoursebtnLayout = new javax.swing.GroupLayout(addcoursebtn);
        addcoursebtn.setLayout(addcoursebtnLayout);
        addcoursebtnLayout.setHorizontalGroup(
            addcoursebtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
            .addGroup(addcoursebtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(addcoursebtnLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jLabel67)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        addcoursebtnLayout.setVerticalGroup(
            addcoursebtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
            .addGroup(addcoursebtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(addcoursebtnLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jLabel67)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );

        panelRound28.add(addcoursebtn);

        updatecoursebtn.setBackground(new java.awt.Color(255, 144, 69));
        updatecoursebtn.setRoundBottomLeft(30);
        updatecoursebtn.setRoundBottomRight(30);
        updatecoursebtn.setRoundTopLeft(30);
        updatecoursebtn.setRoundTopRight(30);
        updatecoursebtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                updatecoursebtnMousePressed(evt);
            }
        });

        jLabel68.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel68.setForeground(new java.awt.Color(255, 255, 255));
        jLabel68.setText("Update Info");

        javax.swing.GroupLayout updatecoursebtnLayout = new javax.swing.GroupLayout(updatecoursebtn);
        updatecoursebtn.setLayout(updatecoursebtnLayout);
        updatecoursebtnLayout.setHorizontalGroup(
            updatecoursebtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
            .addGroup(updatecoursebtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(updatecoursebtnLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jLabel68)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        updatecoursebtnLayout.setVerticalGroup(
            updatecoursebtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
            .addGroup(updatecoursebtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(updatecoursebtnLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jLabel68)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );

        panelRound28.add(updatecoursebtn);

        delcoursebtn.setBackground(new java.awt.Color(255, 144, 69));
        delcoursebtn.setRoundBottomLeft(30);
        delcoursebtn.setRoundBottomRight(30);
        delcoursebtn.setRoundTopLeft(30);
        delcoursebtn.setRoundTopRight(30);
        delcoursebtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                delcoursebtnMousePressed(evt);
            }
        });

        jLabel69.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel69.setForeground(new java.awt.Color(255, 255, 255));
        jLabel69.setText("Delete Course");

        javax.swing.GroupLayout delcoursebtnLayout = new javax.swing.GroupLayout(delcoursebtn);
        delcoursebtn.setLayout(delcoursebtnLayout);
        delcoursebtnLayout.setHorizontalGroup(
            delcoursebtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
            .addGroup(delcoursebtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(delcoursebtnLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jLabel69)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        delcoursebtnLayout.setVerticalGroup(
            delcoursebtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
            .addGroup(delcoursebtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(delcoursebtnLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jLabel69)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );

        panelRound28.add(delcoursebtn);

        resetcoursebtn.setBackground(new java.awt.Color(255, 144, 69));
        resetcoursebtn.setRoundBottomLeft(30);
        resetcoursebtn.setRoundBottomRight(30);
        resetcoursebtn.setRoundTopLeft(30);
        resetcoursebtn.setRoundTopRight(30);
        resetcoursebtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                resetcoursebtnMousePressed(evt);
            }
        });

        jLabel70.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel70.setForeground(new java.awt.Color(255, 255, 255));
        jLabel70.setText("Reset");

        javax.swing.GroupLayout resetcoursebtnLayout = new javax.swing.GroupLayout(resetcoursebtn);
        resetcoursebtn.setLayout(resetcoursebtnLayout);
        resetcoursebtnLayout.setHorizontalGroup(
            resetcoursebtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
            .addGroup(resetcoursebtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(resetcoursebtnLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jLabel70)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        resetcoursebtnLayout.setVerticalGroup(
            resetcoursebtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
            .addGroup(resetcoursebtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(resetcoursebtnLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jLabel70)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );

        panelRound28.add(resetcoursebtn);

        jPanel7.setLayout(new java.awt.GridLayout(4, 2, 5, 5));

        jLabel62.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel62.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel62.setText("Course ID");
        jPanel7.add(jLabel62);
        jPanel7.add(courseID);

        jLabel63.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel63.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel63.setText("Name");
        jPanel7.add(jLabel63);
        jPanel7.add(courseName);

        jLabel64.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel64.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel64.setText("Fee");
        jPanel7.add(jLabel64);
        jPanel7.add(fee);

        jLabel65.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel65.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel65.setText("Course Duration (Weeks)");
        jPanel7.add(jLabel65);

        duration.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                durationActionPerformed(evt);
            }
        });
        jPanel7.add(duration);

        javax.swing.GroupLayout panelRound29Layout = new javax.swing.GroupLayout(panelRound29);
        panelRound29.setLayout(panelRound29Layout);
        panelRound29Layout.setHorizontalGroup(
            panelRound29Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelRound29Layout.createSequentialGroup()
                .addContainerGap(197, Short.MAX_VALUE)
                .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, 516, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(182, 182, 182))
        );
        panelRound29Layout.setVerticalGroup(
            panelRound29Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelRound29Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, 145, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(16, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout CoursesLayout = new javax.swing.GroupLayout(Courses);
        Courses.setLayout(CoursesLayout);
        CoursesLayout.setHorizontalGroup(
            CoursesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(CoursesLayout.createSequentialGroup()
                .addGroup(CoursesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(panelRound28, javax.swing.GroupLayout.PREFERRED_SIZE, 901, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(panelRound29, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(CoursesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addGroup(CoursesLayout.createSequentialGroup()
                            .addContainerGap()
                            .addComponent(panelRound18, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, CoursesLayout.createSequentialGroup()
                            .addGap(19, 19, 19)
                            .addComponent(jLabel61, javax.swing.GroupLayout.PREFERRED_SIZE, 107, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(794, 794, 794))))
                .addContainerGap(1348, Short.MAX_VALUE))
        );
        CoursesLayout.setVerticalGroup(
            CoursesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(CoursesLayout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(jLabel61)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(panelRound29, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(panelRound18, javax.swing.GroupLayout.PREFERRED_SIZE, 219, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(panelRound28, javax.swing.GroupLayout.PREFERRED_SIZE, 59, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(14, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("tab7", Courses);

        Batches.setBackground(new java.awt.Color(0, 0, 0));

        jLabel71.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel71.setForeground(new java.awt.Color(255, 255, 255));
        jLabel71.setText("Batches");

        panelRound30.setRoundBottomLeft(30);
        panelRound30.setRoundBottomRight(30);
        panelRound30.setRoundTopLeft(30);
        panelRound30.setRoundTopRight(30);

        BatchTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "BatchID", "Course"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane6.setViewportView(BatchTable);

        javax.swing.GroupLayout panelRound30Layout = new javax.swing.GroupLayout(panelRound30);
        panelRound30.setLayout(panelRound30Layout);
        panelRound30Layout.setHorizontalGroup(
            panelRound30Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 530, Short.MAX_VALUE)
            .addGroup(panelRound30Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(panelRound30Layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(jScrollPane6, javax.swing.GroupLayout.DEFAULT_SIZE, 518, Short.MAX_VALUE)
                    .addContainerGap()))
        );
        panelRound30Layout.setVerticalGroup(
            panelRound30Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
            .addGroup(panelRound30Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelRound30Layout.createSequentialGroup()
                    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap()))
        );

        panelRound31.setRoundBottomLeft(30);
        panelRound31.setRoundBottomRight(30);
        panelRound31.setRoundTopLeft(30);
        panelRound31.setRoundTopRight(30);

        jPanel8.setLayout(new java.awt.GridLayout(2, 2, 5, 5));

        jLabel72.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel72.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel72.setText("BatchID");
        jPanel8.add(jLabel72);

        batchID.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                batchIDActionPerformed(evt);
            }
        });
        jPanel8.add(batchID);

        jLabel73.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel73.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel73.setText("Course");
        jPanel8.add(jLabel73);

        batch_courses.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "One-on-one personal training", "Physical fitness", "Women's fitness", "Group exercise programs", "Weight loss", "Body-fat reduction", "Muscle toning", "General fitness", "Family fitness", "Sport-specific training", "Children and teens fitness" }));
        jPanel8.add(batch_courses);

        javax.swing.GroupLayout panelRound31Layout = new javax.swing.GroupLayout(panelRound31);
        panelRound31.setLayout(panelRound31Layout);
        panelRound31Layout.setHorizontalGroup(
            panelRound31Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelRound31Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, 433, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        panelRound31Layout.setVerticalGroup(
            panelRound31Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelRound31Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel8, javax.swing.GroupLayout.DEFAULT_SIZE, 89, Short.MAX_VALUE)
                .addContainerGap())
        );

        panelRound32.setBackground(new java.awt.Color(0, 0, 0));
        panelRound32.setLayout(new java.awt.GridLayout(1, 4, 5, 5));

        viewBatchDatabtn.setBackground(new java.awt.Color(255, 144, 69));
        viewBatchDatabtn.setRoundBottomLeft(30);
        viewBatchDatabtn.setRoundBottomRight(30);
        viewBatchDatabtn.setRoundTopLeft(30);
        viewBatchDatabtn.setRoundTopRight(30);
        viewBatchDatabtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                viewBatchDatabtnMousePressed(evt);
            }
        });

        jLabel74.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel74.setForeground(new java.awt.Color(255, 255, 255));
        jLabel74.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel74.setText("View Data");

        javax.swing.GroupLayout viewBatchDatabtnLayout = new javax.swing.GroupLayout(viewBatchDatabtn);
        viewBatchDatabtn.setLayout(viewBatchDatabtnLayout);
        viewBatchDatabtnLayout.setHorizontalGroup(
            viewBatchDatabtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 243, Short.MAX_VALUE)
            .addGroup(viewBatchDatabtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(viewBatchDatabtnLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jLabel74)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        viewBatchDatabtnLayout.setVerticalGroup(
            viewBatchDatabtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 36, Short.MAX_VALUE)
            .addGroup(viewBatchDatabtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(viewBatchDatabtnLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jLabel74)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );

        panelRound32.add(viewBatchDatabtn);

        addBatchbtn.setBackground(new java.awt.Color(255, 144, 69));
        addBatchbtn.setRoundBottomLeft(30);
        addBatchbtn.setRoundBottomRight(30);
        addBatchbtn.setRoundTopLeft(30);
        addBatchbtn.setRoundTopRight(30);
        addBatchbtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                addBatchbtnMousePressed(evt);
            }
        });

        jLabel76.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel76.setForeground(new java.awt.Color(255, 255, 255));
        jLabel76.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel76.setText("Add New Batch");

        javax.swing.GroupLayout addBatchbtnLayout = new javax.swing.GroupLayout(addBatchbtn);
        addBatchbtn.setLayout(addBatchbtnLayout);
        addBatchbtnLayout.setHorizontalGroup(
            addBatchbtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 243, Short.MAX_VALUE)
            .addGroup(addBatchbtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(addBatchbtnLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jLabel76)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        addBatchbtnLayout.setVerticalGroup(
            addBatchbtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 36, Short.MAX_VALUE)
            .addGroup(addBatchbtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(addBatchbtnLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jLabel76)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );

        panelRound32.add(addBatchbtn);

        updateBatchbtn.setBackground(new java.awt.Color(255, 144, 69));
        updateBatchbtn.setRoundBottomLeft(30);
        updateBatchbtn.setRoundBottomRight(30);
        updateBatchbtn.setRoundTopLeft(30);
        updateBatchbtn.setRoundTopRight(30);
        updateBatchbtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                updateBatchbtnMousePressed(evt);
            }
        });

        jLabel75.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel75.setForeground(new java.awt.Color(255, 255, 255));
        jLabel75.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel75.setText("Update Info");

        javax.swing.GroupLayout updateBatchbtnLayout = new javax.swing.GroupLayout(updateBatchbtn);
        updateBatchbtn.setLayout(updateBatchbtnLayout);
        updateBatchbtnLayout.setHorizontalGroup(
            updateBatchbtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 243, Short.MAX_VALUE)
            .addGroup(updateBatchbtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(updateBatchbtnLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jLabel75)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        updateBatchbtnLayout.setVerticalGroup(
            updateBatchbtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 36, Short.MAX_VALUE)
            .addGroup(updateBatchbtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(updateBatchbtnLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jLabel75)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );

        panelRound32.add(updateBatchbtn);

        delBatchbtn.setBackground(new java.awt.Color(255, 144, 69));
        delBatchbtn.setRoundBottomLeft(30);
        delBatchbtn.setRoundBottomRight(30);
        delBatchbtn.setRoundTopLeft(30);
        delBatchbtn.setRoundTopRight(30);
        delBatchbtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                delBatchbtnMousePressed(evt);
            }
        });

        jLabel77.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel77.setForeground(new java.awt.Color(255, 255, 255));
        jLabel77.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel77.setText("Delete Batch");

        javax.swing.GroupLayout delBatchbtnLayout = new javax.swing.GroupLayout(delBatchbtn);
        delBatchbtn.setLayout(delBatchbtnLayout);
        delBatchbtnLayout.setHorizontalGroup(
            delBatchbtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 243, Short.MAX_VALUE)
            .addGroup(delBatchbtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(delBatchbtnLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jLabel77)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        delBatchbtnLayout.setVerticalGroup(
            delBatchbtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 36, Short.MAX_VALUE)
            .addGroup(delBatchbtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(delBatchbtnLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jLabel77)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );

        panelRound32.add(delBatchbtn);

        panelRound35.setBackground(new java.awt.Color(255, 255, 255));
        panelRound35.setRoundBottomLeft(30);
        panelRound35.setRoundBottomRight(30);
        panelRound35.setRoundTopLeft(30);
        panelRound35.setRoundTopRight(30);

        batch701btn.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        batch701btn.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        batch701btn.setText("Batch 701");
        batch701btn.setToolTipText("Click to view data");
        batch701btn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                batch701btnMousePressed(evt);
            }
        });

        batch701.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "First Name", "Last Name"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        batch701.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                batch701MousePressed(evt);
            }
        });
        jScrollPane7.setViewportView(batch701);

        javax.swing.GroupLayout panelRound35Layout = new javax.swing.GroupLayout(panelRound35);
        panelRound35.setLayout(panelRound35Layout);
        panelRound35Layout.setHorizontalGroup(
            panelRound35Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(batch701btn, javax.swing.GroupLayout.DEFAULT_SIZE, 197, Short.MAX_VALUE)
            .addComponent(jScrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
        );
        panelRound35Layout.setVerticalGroup(
            panelRound35Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelRound35Layout.createSequentialGroup()
                .addComponent(batch701btn, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jScrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        panelRound36.setBackground(new java.awt.Color(255, 255, 255));
        panelRound36.setRoundBottomLeft(30);
        panelRound36.setRoundBottomRight(30);
        panelRound36.setRoundTopLeft(30);
        panelRound36.setRoundTopRight(30);

        batch721btn.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        batch721btn.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        batch721btn.setText("Batch 721");
        batch721btn.setToolTipText("Click to view data");
        batch721btn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                batch721btnMousePressed(evt);
            }
        });

        batch721.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "First Name", "Last Name"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        batch721.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                batch721MousePressed(evt);
            }
        });
        jScrollPane8.setViewportView(batch721);

        javax.swing.GroupLayout panelRound36Layout = new javax.swing.GroupLayout(panelRound36);
        panelRound36.setLayout(panelRound36Layout);
        panelRound36Layout.setHorizontalGroup(
            panelRound36Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(batch721btn, javax.swing.GroupLayout.DEFAULT_SIZE, 197, Short.MAX_VALUE)
            .addComponent(jScrollPane8, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
        );
        panelRound36Layout.setVerticalGroup(
            panelRound36Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelRound36Layout.createSequentialGroup()
                .addComponent(batch721btn, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jScrollPane8, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        panelRound37.setBackground(new java.awt.Color(255, 255, 255));
        panelRound37.setRoundBottomLeft(30);
        panelRound37.setRoundBottomRight(30);
        panelRound37.setRoundTopLeft(30);
        panelRound37.setRoundTopRight(30);

        batch798btn.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        batch798btn.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        batch798btn.setText("Batch 798");
        batch798btn.setToolTipText("Click to view data");
        batch798btn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                batch798btnMousePressed(evt);
            }
        });

        batch798.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "First Name", "Last Name"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        batch798.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                batch798MousePressed(evt);
            }
        });
        jScrollPane9.setViewportView(batch798);

        javax.swing.GroupLayout panelRound37Layout = new javax.swing.GroupLayout(panelRound37);
        panelRound37.setLayout(panelRound37Layout);
        panelRound37Layout.setHorizontalGroup(
            panelRound37Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(batch798btn, javax.swing.GroupLayout.DEFAULT_SIZE, 197, Short.MAX_VALUE)
            .addComponent(jScrollPane9, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
        );
        panelRound37Layout.setVerticalGroup(
            panelRound37Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelRound37Layout.createSequentialGroup()
                .addComponent(batch798btn, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jScrollPane9, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(14, 14, 14))
        );

        panelRound39.setBackground(new java.awt.Color(255, 255, 255));
        panelRound39.setRoundBottomLeft(30);
        panelRound39.setRoundBottomRight(30);
        panelRound39.setRoundTopLeft(30);
        panelRound39.setRoundTopRight(30);

        batch745btn.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        batch745btn.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        batch745btn.setText("Batch 745");
        batch745btn.setToolTipText("Click to view data");
        batch745btn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                batch745btnMousePressed(evt);
            }
        });

        batch745.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "First Name", "Last Name"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        batch745.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                batch745MousePressed(evt);
            }
        });
        jScrollPane11.setViewportView(batch745);

        javax.swing.GroupLayout panelRound39Layout = new javax.swing.GroupLayout(panelRound39);
        panelRound39.setLayout(panelRound39Layout);
        panelRound39Layout.setHorizontalGroup(
            panelRound39Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(batch745btn, javax.swing.GroupLayout.DEFAULT_SIZE, 197, Short.MAX_VALUE)
            .addComponent(jScrollPane11, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
        );
        panelRound39Layout.setVerticalGroup(
            panelRound39Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelRound39Layout.createSequentialGroup()
                .addComponent(batch745btn, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane11, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        panelRound40.setBackground(new java.awt.Color(255, 255, 255));
        panelRound40.setRoundBottomLeft(30);
        panelRound40.setRoundBottomRight(30);
        panelRound40.setRoundTopLeft(30);
        panelRound40.setRoundTopRight(30);

        batch789btn.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        batch789btn.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        batch789btn.setText("Batch 789");
        batch789btn.setToolTipText("Click to view data");
        batch789btn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                batch789btnMousePressed(evt);
            }
        });

        batch789.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "First Name", "Last Name"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        batch789.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                batch789MousePressed(evt);
            }
        });
        jScrollPane12.setViewportView(batch789);

        javax.swing.GroupLayout panelRound40Layout = new javax.swing.GroupLayout(panelRound40);
        panelRound40.setLayout(panelRound40Layout);
        panelRound40Layout.setHorizontalGroup(
            panelRound40Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(batch789btn, javax.swing.GroupLayout.DEFAULT_SIZE, 197, Short.MAX_VALUE)
            .addComponent(jScrollPane12, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
        );
        panelRound40Layout.setVerticalGroup(
            panelRound40Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelRound40Layout.createSequentialGroup()
                .addComponent(batch789btn, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 14, Short.MAX_VALUE)
                .addComponent(jScrollPane12, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(14, 14, 14))
        );

        panelRound41.setBackground(new java.awt.Color(255, 255, 255));
        panelRound41.setRoundBottomLeft(30);
        panelRound41.setRoundBottomRight(30);
        panelRound41.setRoundTopLeft(30);
        panelRound41.setRoundTopRight(30);

        batch709btn.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        batch709btn.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        batch709btn.setText("Batch 709");
        batch709btn.setToolTipText("Click to view data");
        batch709btn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                batch709btnMousePressed(evt);
            }
        });

        batch709.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "First Name", "Last Name"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        batch709.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                batch709MousePressed(evt);
            }
        });
        jScrollPane13.setViewportView(batch709);

        javax.swing.GroupLayout panelRound41Layout = new javax.swing.GroupLayout(panelRound41);
        panelRound41.setLayout(panelRound41Layout);
        panelRound41Layout.setHorizontalGroup(
            panelRound41Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(batch709btn, javax.swing.GroupLayout.DEFAULT_SIZE, 197, Short.MAX_VALUE)
            .addComponent(jScrollPane13, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
        );
        panelRound41Layout.setVerticalGroup(
            panelRound41Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelRound41Layout.createSequentialGroup()
                .addComponent(batch709btn, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jScrollPane13, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(33, 33, 33))
        );

        panelRound44.setBackground(new java.awt.Color(255, 255, 255));
        panelRound44.setRoundBottomLeft(30);
        panelRound44.setRoundBottomRight(30);
        panelRound44.setRoundTopLeft(30);
        panelRound44.setRoundTopRight(30);

        batch767btn.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        batch767btn.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        batch767btn.setText("Batch 767");
        batch767btn.setToolTipText("Click to view data");
        batch767btn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                batch767btnMousePressed(evt);
            }
        });

        batch767.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "First Name", "Last Name"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        batch767.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                batch767MousePressed(evt);
            }
        });
        jScrollPane16.setViewportView(batch767);

        javax.swing.GroupLayout panelRound44Layout = new javax.swing.GroupLayout(panelRound44);
        panelRound44.setLayout(panelRound44Layout);
        panelRound44Layout.setHorizontalGroup(
            panelRound44Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(batch767btn, javax.swing.GroupLayout.DEFAULT_SIZE, 197, Short.MAX_VALUE)
            .addComponent(jScrollPane16, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
        );
        panelRound44Layout.setVerticalGroup(
            panelRound44Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelRound44Layout.createSequentialGroup()
                .addComponent(batch767btn, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane16, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        panelRound42.setBackground(new java.awt.Color(255, 255, 255));
        panelRound42.setRoundBottomLeft(30);
        panelRound42.setRoundBottomRight(30);
        panelRound42.setRoundTopLeft(30);
        panelRound42.setRoundTopRight(30);

        batch734btn.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        batch734btn.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        batch734btn.setText("Batch 734");
        batch734btn.setToolTipText("Click to view data");
        batch734btn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                batch734btnMousePressed(evt);
            }
        });

        batch734.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "First Name", "Last Name"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        batch734.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                batch734MousePressed(evt);
            }
        });
        jScrollPane14.setViewportView(batch734);

        javax.swing.GroupLayout panelRound42Layout = new javax.swing.GroupLayout(panelRound42);
        panelRound42.setLayout(panelRound42Layout);
        panelRound42Layout.setHorizontalGroup(
            panelRound42Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(batch734btn, javax.swing.GroupLayout.DEFAULT_SIZE, 197, Short.MAX_VALUE)
            .addComponent(jScrollPane14, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
        );
        panelRound42Layout.setVerticalGroup(
            panelRound42Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelRound42Layout.createSequentialGroup()
                .addComponent(batch734btn, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jScrollPane14, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(33, 33, 33))
        );

        panelRound43.setBackground(new java.awt.Color(255, 255, 255));
        panelRound43.setRoundBottomLeft(30);
        panelRound43.setRoundBottomRight(30);
        panelRound43.setRoundTopLeft(30);
        panelRound43.setRoundTopRight(30);

        batch777btn.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        batch777btn.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        batch777btn.setText("Batch 777");
        batch777btn.setToolTipText("Click to view data");
        batch777btn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                batch777btnMousePressed(evt);
            }
        });

        batch777.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "First Name", "Last Name"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        batch777.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                batch777MousePressed(evt);
            }
        });
        jScrollPane15.setViewportView(batch777);

        javax.swing.GroupLayout panelRound43Layout = new javax.swing.GroupLayout(panelRound43);
        panelRound43.setLayout(panelRound43Layout);
        panelRound43Layout.setHorizontalGroup(
            panelRound43Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(batch777btn, javax.swing.GroupLayout.DEFAULT_SIZE, 197, Short.MAX_VALUE)
            .addComponent(jScrollPane15, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
        );
        panelRound43Layout.setVerticalGroup(
            panelRound43Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelRound43Layout.createSequentialGroup()
                .addComponent(batch777btn, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jScrollPane15, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(33, 33, 33))
        );

        panelRound46.setBackground(new java.awt.Color(255, 255, 255));
        panelRound46.setRoundBottomLeft(30);
        panelRound46.setRoundBottomRight(30);
        panelRound46.setRoundTopLeft(30);
        panelRound46.setRoundTopRight(30);

        batch788btn.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        batch788btn.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        batch788btn.setText("Batch 788");
        batch788btn.setToolTipText("Click to view data");
        batch788btn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                batch788btnMousePressed(evt);
            }
        });

        batch788.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "First Name", "Last Name"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        batch788.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                batch788MousePressed(evt);
            }
        });
        jScrollPane18.setViewportView(batch788);

        javax.swing.GroupLayout panelRound46Layout = new javax.swing.GroupLayout(panelRound46);
        panelRound46.setLayout(panelRound46Layout);
        panelRound46Layout.setHorizontalGroup(
            panelRound46Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(batch788btn, javax.swing.GroupLayout.DEFAULT_SIZE, 197, Short.MAX_VALUE)
            .addComponent(jScrollPane18, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
        );
        panelRound46Layout.setVerticalGroup(
            panelRound46Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelRound46Layout.createSequentialGroup()
                .addComponent(batch788btn, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jScrollPane18, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(33, 33, 33))
        );

        panelRound47.setBackground(new java.awt.Color(255, 255, 255));
        panelRound47.setRoundBottomLeft(30);
        panelRound47.setRoundBottomRight(30);
        panelRound47.setRoundTopLeft(30);
        panelRound47.setRoundTopRight(30);

        batch799btn.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        batch799btn.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        batch799btn.setText("Batch 799");
        batch799btn.setToolTipText("Click to view data");
        batch799btn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                batch799btnMousePressed(evt);
            }
        });

        batch799.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "First Name", "Last Name"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        batch799.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                batch799MousePressed(evt);
            }
        });
        jScrollPane19.setViewportView(batch799);

        javax.swing.GroupLayout panelRound47Layout = new javax.swing.GroupLayout(panelRound47);
        panelRound47.setLayout(panelRound47Layout);
        panelRound47Layout.setHorizontalGroup(
            panelRound47Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(batch799btn, javax.swing.GroupLayout.DEFAULT_SIZE, 197, Short.MAX_VALUE)
            .addComponent(jScrollPane19, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
        );
        panelRound47Layout.setVerticalGroup(
            panelRound47Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelRound47Layout.createSequentialGroup()
                .addComponent(batch799btn)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane19, javax.swing.GroupLayout.DEFAULT_SIZE, 61, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout BatchesLayout = new javax.swing.GroupLayout(Batches);
        Batches.setLayout(BatchesLayout);
        BatchesLayout.setHorizontalGroup(
            BatchesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(BatchesLayout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addGroup(BatchesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(BatchesLayout.createSequentialGroup()
                        .addGroup(BatchesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel71, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, BatchesLayout.createSequentialGroup()
                                .addComponent(panelRound40, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(panelRound41, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(panelRound42, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(panelRound43, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(panelRound46, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(panelRound30, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(panelRound32, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 987, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addContainerGap())
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, BatchesLayout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addGroup(BatchesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, BatchesLayout.createSequentialGroup()
                                .addComponent(panelRound35, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(panelRound36, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(panelRound37, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(panelRound39, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(panelRound44, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(1238, 1238, 1238))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, BatchesLayout.createSequentialGroup()
                                .addComponent(panelRound31, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(1260, 1260, 1260))))
                    .addGroup(BatchesLayout.createSequentialGroup()
                        .addComponent(panelRound47, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))))
        );
        BatchesLayout.setVerticalGroup(
            BatchesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(BatchesLayout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addComponent(jLabel71)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(BatchesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(panelRound31, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(panelRound30, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(panelRound32, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(BatchesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(panelRound35, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addComponent(panelRound36, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(panelRound37, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addComponent(panelRound39, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(panelRound44, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(BatchesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(panelRound43, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addComponent(panelRound42, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addComponent(panelRound46, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addComponent(panelRound40, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(panelRound41, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(panelRound47, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        jTabbedPane1.addTab("tab8", Batches);

        Schedules.setBackground(new java.awt.Color(0, 0, 0));

        javax.swing.GroupLayout SchedulesLayout = new javax.swing.GroupLayout(Schedules);
        Schedules.setLayout(SchedulesLayout);
        SchedulesLayout.setHorizontalGroup(
            SchedulesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 2268, Short.MAX_VALUE)
        );
        SchedulesLayout.setVerticalGroup(
            SchedulesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 539, Short.MAX_VALUE)
        );

        jTabbedPane1.addTab("tab9", Schedules);

        jPanel1.add(jTabbedPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(247, 6, -1, 570));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void CustomerAdmissionMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_CustomerAdmissionMouseClicked
        
    }//GEN-LAST:event_CustomerAdmissionMouseClicked

    private void adddeetsbtnMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_adddeetsbtnMousePressed
        DefaultTableModel RecordTable = (DefaultTableModel)CustomerAdmission.getModel();
        int SelectedRows = CustomerAdmission.getSelectedRow();
        
        try{
            int Id = Integer.parseInt(RecordTable.getValueAt(SelectedRows, 0).toString());
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection(dataConn,username,"");
            prep = con.prepareStatement("UPDATE customers SET customerID = ? WHERE ID = ? ");
            prep.setString(1, customerID.getText());
            prep.setInt(2, Id);

            prep.executeUpdate();
            JOptionPane.showMessageDialog(this, "Customer details added successfully");
            updatecustomerDB();
            prep = con.prepareStatement("UPDATE customers tbl1 INNER JOIN batches tbl2 ON tbl1.course_registered = tbl2.course SET tbl1.batch_number = tbl2.batchID;");
            prep.executeUpdate();
            updatecustomerDB();
        } catch (SQLException ex) {

        } catch (ClassNotFoundException ex) {
            Logger.getLogger(FitnessManagerAsstDashboard.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_adddeetsbtnMousePressed

    private void updatedeetsbtnMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_updatedeetsbtnMousePressed
        DefaultTableModel RecordTable = (DefaultTableModel)CustomerAdmission.getModel();
        int SelectedRows = CustomerAdmission.getSelectedRow();
        
        
            try{
                int Id = Integer.parseInt(RecordTable.getValueAt(SelectedRows, 0).toString());
                Class.forName("com.mysql.cj.jdbc.Driver");
                con = DriverManager.getConnection(dataConn,username,"");
                prep = con.prepareStatement("UPDATE customers SET customerID = ? WHERE ID = ?");
                prep.setString(1, customerID.getText());
                prep.setInt(2, Id);

                prep.executeUpdate();
                JOptionPane.showMessageDialog(this, "Customer details updated successfully");
                updatecustomerDB();
                prep = con.prepareStatement("UPDATE customers tbl1 INNER JOIN batches tbl2 ON tbl1.course_registered = tbl2.course SET tbl1.batch_number = tbl2.batchID;");
                prep.executeUpdate();
                updatecustomerDB();
            } catch (SQLException ex) {

            } catch (ClassNotFoundException ex) {
                Logger.getLogger(FitnessManagerAsstDashboard.class.getName()).log(Level.SEVERE, null, ex);
            }
        
        

    }//GEN-LAST:event_updatedeetsbtnMousePressed

    private void resetbtnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_resetbtnMouseClicked
        customerID.setText("");
    }//GEN-LAST:event_resetbtnMouseClicked

    private void CustomerAdmissionMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_CustomerAdmissionMousePressed
        DefaultTableModel RecordTable = (DefaultTableModel)CustomerAdmission.getModel();
        int SelectedRows = CustomerAdmission.getSelectedRow();

        customerID.setText(RecordTable.getValueAt(SelectedRows, 1).toString());
    }//GEN-LAST:event_CustomerAdmissionMousePressed

    private void nameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_nameActionPerformed

    private void resetbookbtnMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_resetbookbtnMousePressed
        bookID.setText("");
        name.setText("");
        price.setText("");
        quantity.setText("");
    }//GEN-LAST:event_resetbookbtnMousePressed

    private void addbookbtnMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_addbookbtnMousePressed
        
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection(dataConn,username,"");
            prep = con.prepareStatement("INSERT INTO books(bookID, name, price, quantity) VALUES(?,?,?,?)");
            prep.setString(1, bookID.getText());
            prep.setString(2, name.getText());
            prep.setString(3, price.getText());
            prep.setString(4, quantity.getText());

            prep.executeUpdate();
            JOptionPane.showMessageDialog(this, "Book added successfully");
            updatebookDB();
        } catch (SQLException ex) {

        } catch (ClassNotFoundException ex) {
            Logger.getLogger(FitnessManagerAsstDashboard.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_addbookbtnMousePressed

    private void updatebookbtnMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_updatebookbtnMousePressed
        DefaultTableModel RecordTable = (DefaultTableModel)BookDetails.getModel();
        int SelectedRows = BookDetails.getSelectedRow();

        String[] choices = {"BookID","Name","Price","Quantity","All"};
        int updateInput = JOptionPane.showOptionDialog(this, "Select a field to update", "Update Book Details", 0, 3, null, choices, choices[0]);
//        int id = Integer.parseInt(JOptionPane.showInputDialog(this, "Input ID of book(not BookID)"));
        
        if(updateInput==0){
            try{
                int Id = Integer.parseInt(RecordTable.getValueAt(SelectedRows, 0).toString());
                Class.forName("com.mysql.jdbc.Driver");
                con = DriverManager.getConnection(dataConn,username,"");
                prep = con.prepareStatement("UPDATE books SET bookID = ? WHERE ID = ?");
                prep.setString(1, bookID.getText());
                prep.setInt(2, Id);
                
                prep.executeUpdate();
                JOptionPane.showMessageDialog(this, "Book details updated successfully");
                updatebookDB();
            }catch(SQLException e){
                
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(FitnessManagerManDashboard.class.getName()).log(Level.SEVERE, null, ex);
            }
        }else if(updateInput == 1){
            try{
                int Id = Integer.parseInt(RecordTable.getValueAt(SelectedRows, 0).toString());
                Class.forName("com.mysql.jdbc.Driver");
                con = DriverManager.getConnection(dataConn,username,"");
                prep = con.prepareStatement("UPDATE books SET name = ? WHERE ID = ?");
                prep.setString(1, name.getText());
                prep.setInt(2, Id);
                
                prep.executeUpdate();
                JOptionPane.showMessageDialog(this, "Book details updated successfully");
                updatebookDB();
            }catch(SQLException e){
                
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(FitnessManagerManDashboard.class.getName()).log(Level.SEVERE, null, ex);
            }
        }else if(updateInput == 2){
            try{
                int Id = Integer.parseInt(RecordTable.getValueAt(SelectedRows, 0).toString());
                Class.forName("com.mysql.jdbc.Driver");
                con = DriverManager.getConnection(dataConn,username,"");
                prep = con.prepareStatement("UPDATE books SET price = ? WHERE ID = ?");
                prep.setString(1, price.getText());
                prep.setInt(2, Id);
                
                prep.executeUpdate();
                JOptionPane.showMessageDialog(this, "Book details updated successfully");
                updatebookDB();
            }catch(SQLException e){
                
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(FitnessManagerManDashboard.class.getName()).log(Level.SEVERE, null, ex);
            }
        }else if(updateInput == 3){
            try{
                int Id = Integer.parseInt(RecordTable.getValueAt(SelectedRows, 0).toString());
                Class.forName("com.mysql.jdbc.Driver");
                con = DriverManager.getConnection(dataConn,username,"");
                prep = con.prepareStatement("UPDATE books SET quantity = ? WHERE ID = ?");
                prep.setString(1, quantity.getText());
                prep.setInt(2, Id);
                
                prep.executeUpdate();
                JOptionPane.showMessageDialog(this, "Book details updated successfully");
                updatebookDB();
            }catch(SQLException e){
                
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(FitnessManagerManDashboard.class.getName()).log(Level.SEVERE, null, ex);
            }
        }else if(updateInput == 4){
            try{
                int Id = Integer.parseInt(RecordTable.getValueAt(SelectedRows, 0).toString());
                Class.forName("com.mysql.jdbc.Driver");
                con = DriverManager.getConnection(dataConn,username,"");
                prep = con.prepareStatement("UPDATE books SET bookID = ?, name = ?, price = ?, quantity = ? WHERE ID = ?");
                prep.setString(1, bookID.getText());
                prep.setString(2, name.getText());
                prep.setString(3, price.getText());
                prep.setString(4, quantity.getText());
                prep.setInt(5, Id);

                prep.executeUpdate();
                JOptionPane.showMessageDialog(this, "Book details updated successfully");
                updatebookDB();
            } catch (SQLException ex) {

            } catch (ClassNotFoundException ex) {
                Logger.getLogger(FitnessManagerAsstDashboard.class.getName()).log(Level.SEVERE, null, ex);
            }
        }        
                   
    }//GEN-LAST:event_updatebookbtnMousePressed

    private void deletebookbtnMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_deletebookbtnMouseEntered
        
    }//GEN-LAST:event_deletebookbtnMouseEntered

    private void BookDetailsFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_BookDetailsFocusGained
        
    }//GEN-LAST:event_BookDetailsFocusGained

    private void BookDetailsMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BookDetailsMousePressed
        DefaultTableModel RecordTable = (DefaultTableModel)BookDetails.getModel();
        int SelectedRows = BookDetails.getSelectedRow();

        bookID.setText(RecordTable.getValueAt(SelectedRows, 1).toString());
        name.setText(RecordTable.getValueAt(SelectedRows, 2).toString());
        price.setText(RecordTable.getValueAt(SelectedRows, 3).toString());
        quantity.setText(RecordTable.getValueAt(SelectedRows, 4).toString());
    }//GEN-LAST:event_BookDetailsMousePressed

    private void viewDataMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_viewDataMousePressed
        try{
            con = DriverManager.getConnection(dataConn,username,"");
            prep = con.prepareStatement("SELECT * FROM books");
            ResultSet rs = prep.executeQuery();
            DefaultTableModel model = (DefaultTableModel)BookDetails.getModel();
            while(rs.next()){
                model.addRow(new String[]{rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5)});
            }
            updatebookDB();
        }catch(SQLException e){
            
        }
    }//GEN-LAST:event_viewDataMousePressed

    private void deletebookbtnMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_deletebookbtnMousePressed
        DefaultTableModel RecordTable = (DefaultTableModel)BookDetails.getModel();
        int SelectedRows = BookDetails.getSelectedRow();
        try{
            int id = Integer.parseInt(RecordTable.getValueAt(SelectedRows, 0).toString());
            int deleteItem = JOptionPane.showConfirmDialog(null, "Confirm if you want to delete item", "Warning", JOptionPane.YES_NO_OPTION);
            if(deleteItem==JOptionPane.YES_OPTION){
                Class.forName("com.mysql.cj.jdbc.Driver"); 
                con = DriverManager.getConnection(dataConn,username,"");
                prep = con.prepareStatement("DELETE FROM books WHERE ID = ?");
                prep.setInt(1, id);

                prep.executeUpdate();
                JOptionPane.showMessageDialog(this, "Customer deleted successfully");
                updatebookDB();
                
                bookID.setText("");
                bookID.requestFocus();
                name.setText("");
                price.setText("");
                quantity.setText("");
            }
        }catch(SQLException e){
            
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(FitnessManagerAsstDashboard.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_deletebookbtnMousePressed

    private void viewCustomerDatabtnMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_viewCustomerDatabtnMousePressed
//        boolean has_been_clicked = false;
//
//        if(evt.getSource() == viewCustomerDatabtn){
//            has_been_clicked = true;
//        }
        try{
            con = DriverManager.getConnection(dataConn,username,"");
            prep = con.prepareStatement("SELECT * FROM customers WHERE joined = 'Yes'");
            ResultSet rs = prep.executeQuery();
            DefaultTableModel model = (DefaultTableModel)CustomerAdmission.getModel();
                while(rs.next()){
                    model.addRow(new String[]{rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6),rs.getString(7),rs.getString(8),rs.getString(9)});
                }
            updatecustomerDB();
            
        }catch(SQLException e){

        }
        
    }//GEN-LAST:event_viewCustomerDatabtnMousePressed

    private void addempbtnMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_addempbtnMousePressed
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection(dataConn,username,"");
            prep = con.prepareStatement("INSERT INTO employees(employeeID, firstname, lastname, email, course_tutoring, position) VALUES(?,?,?,?,?,?)");
            prep.setString(1, employeeID.getText());
            prep.setString(2, empFirstName.getText());
            prep.setString(3, empLastName.getText());
            prep.setString(4, empEmail.getText());
            prep.setString(5, (String) course_tutoring.getSelectedItem());
            prep.setString(6, (String) position.getSelectedItem());

            prep.executeUpdate();
            JOptionPane.showMessageDialog(this, "Employee added successfully");
            updateemployeeDB();
        } catch (SQLException ex) {

        } catch (ClassNotFoundException ex) {
            Logger.getLogger(FitnessManagerAsstDashboard.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_addempbtnMousePressed

    private void resetempbtnMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_resetempbtnMousePressed
         employeeID.setText("");
         empFirstName.setText("");
         empLastName.setText("");
         empEmail.setText("");
         course_tutoring.setSelectedIndex(0);
         position.setSelectedIndex(0);
    }//GEN-LAST:event_resetempbtnMousePressed

    private void empEmailActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_empEmailActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_empEmailActionPerformed

    private void updateempbtnMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_updateempbtnMousePressed
        DefaultTableModel RecordTable = (DefaultTableModel)EmployeeTable.getModel();
        int SelectedRows = EmployeeTable.getSelectedRow();
        
        
        String[] choices = {"EmployeeID","First Name","Last Name","Email","Course","Position","All"};
        int updateInput = JOptionPane.showOptionDialog(this, "Select a field to update", "Update Employee Details", 0, 3, null, choices, choices[0]);

        
        if(updateInput==0){
            try{
                int Id = Integer.parseInt(RecordTable.getValueAt(SelectedRows, 0).toString());
                Class.forName("com.mysql.jdbc.Driver");
                con = DriverManager.getConnection(dataConn,username,"");
                prep = con.prepareStatement("UPDATE employees SET employeeID = ? WHERE ID = ?");
                prep.setString(1, employeeID.getText());
                prep.setInt(2, Id);                
                
                prep.executeUpdate();
                JOptionPane.showMessageDialog(this, "Employee details updated successfully");
                updateemployeeDB();
            }catch(SQLException e){
                
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(FitnessManagerManDashboard.class.getName()).log(Level.SEVERE, null, ex);
            }
        }else if(updateInput == 1){
            try{
                int Id = Integer.parseInt(RecordTable.getValueAt(SelectedRows, 0).toString());
                Class.forName("com.mysql.jdbc.Driver");
                con = DriverManager.getConnection(dataConn,username,"");
                prep = con.prepareStatement("UPDATE employees SET firstname = ? WHERE ID = ?");
                prep.setString(1, empFirstName.getText());
                prep.setInt(2, Id);
                
                prep.executeUpdate();
                JOptionPane.showMessageDialog(this, "Employee details updated successfully");
                updateemployeeDB();
            }catch(SQLException e){
                
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(FitnessManagerManDashboard.class.getName()).log(Level.SEVERE, null, ex);
            }
        }else if(updateInput == 2){
            try{
                int Id = Integer.parseInt(RecordTable.getValueAt(SelectedRows, 0).toString());
                Class.forName("com.mysql.jdbc.Driver");
                con = DriverManager.getConnection(dataConn,username,"");
                prep = con.prepareStatement("UPDATE employees SET lastname = ? WHERE ID = ?");
                prep.setString(1, empLastName.getText());
                prep.setInt(2, Id);
                
                prep.executeUpdate();
                JOptionPane.showMessageDialog(this, "Employee details updated successfully");
                updateemployeeDB();
            }catch(SQLException e){
                
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(FitnessManagerManDashboard.class.getName()).log(Level.SEVERE, null, ex);
            }
        }else if(updateInput == 3){
            try{
                int Id = Integer.parseInt(RecordTable.getValueAt(SelectedRows, 0).toString());
                Class.forName("com.mysql.jdbc.Driver");
                con = DriverManager.getConnection(dataConn,username,"");
                prep = con.prepareStatement("UPDATE employees SET email = ? WHERE ID = ?");
                prep.setString(1, empEmail.getText());
                prep.setInt(2, Id);
                
                prep.executeUpdate();
                JOptionPane.showMessageDialog(this, "Employee details updated successfully");
                updateemployeeDB();
            }catch(SQLException e){
                
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(FitnessManagerManDashboard.class.getName()).log(Level.SEVERE, null, ex);
            }
        }else if(updateInput == 4){
            try{
                int Id = Integer.parseInt(RecordTable.getValueAt(SelectedRows, 0).toString());
                Class.forName("com.mysql.jdbc.Driver");
                con = DriverManager.getConnection(dataConn,username,"");
                prep = con.prepareStatement("UPDATE employees SET course_tutoring = ? WHERE ID = ?");
                prep.setString(1, (String) course_tutoring.getSelectedItem());
                prep.setInt(2, Id);
                
                prep.executeUpdate();
                JOptionPane.showMessageDialog(this, "Employee details updated successfully");
                updateemployeeDB();
            }catch(SQLException e){
                
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(FitnessManagerManDashboard.class.getName()).log(Level.SEVERE, null, ex);
            }
        }else if(updateInput == 5){
            try{
                int Id = Integer.parseInt(RecordTable.getValueAt(SelectedRows, 0).toString());
                Class.forName("com.mysql.jdbc.Driver");
                con = DriverManager.getConnection(dataConn,username,"");
                prep = con.prepareStatement("UPDATE employees SET position = ? WHERE ID = ?");
                prep.setString(1, (String) position.getSelectedItem());
                prep.setInt(2, Id);
                
                prep.executeUpdate();
                JOptionPane.showMessageDialog(this, "Employee details updated successfully");
                updateemployeeDB();
            }catch(SQLException e){
                
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(FitnessManagerManDashboard.class.getName()).log(Level.SEVERE, null, ex);
            }
        }else if(updateInput == 6){
            try{
                int Id = Integer.parseInt(RecordTable.getValueAt(SelectedRows, 0).toString());
                Class.forName("com.mysql.jdbc.Driver");
                con = DriverManager.getConnection(dataConn,username,"");
                prep = con.prepareStatement("UPDATE employees SET employeeID = ?, firstname = ?, lastname = ?, email = ?, course_tutoring = ?, position = ? WHERE ID = ?");
                prep.setString(1, employeeID.getText());
                prep.setString(2, empFirstName.getText());
                prep.setString(3, empLastName.getText());
                prep.setString(4, empEmail.getText());
                prep.setString(5, (String) course_tutoring.getSelectedItem());
                prep.setString(6, (String) position.getSelectedItem());
                prep.setInt(7, Id);

                prep.executeUpdate();
                JOptionPane.showMessageDialog(this, "Employee details updated successfully");
                updateemployeeDB();
            } catch (SQLException ex) {

            } catch (ClassNotFoundException ex) {
                Logger.getLogger(FitnessManagerAsstDashboard.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }//GEN-LAST:event_updateempbtnMousePressed

    private void deleteempbtnMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_deleteempbtnMousePressed
        DefaultTableModel RecordTable = (DefaultTableModel)EmployeeTable.getModel();
        int SelectedRows = EmployeeTable.getSelectedRow();
        try{
            int id = Integer.parseInt(RecordTable.getValueAt(SelectedRows, 0).toString());
            int deleteItem = JOptionPane.showConfirmDialog(null, "Confirm if you want to delete item", "Warning", JOptionPane.YES_NO_OPTION);
            if(deleteItem==JOptionPane.YES_OPTION){
                Class.forName("com.mysql.cj.jdbc.Driver"); 
                con = DriverManager.getConnection(dataConn,username,"");
                prep = con.prepareStatement("DELETE FROM employees WHERE ID = ?");
                prep.setInt(1, id);

                prep.executeUpdate();
                JOptionPane.showMessageDialog(this, "Employee deleted successfully");
                updateemployeeDB();
                
                employeeID.setText("");
                employeeID.requestFocus();
                empFirstName.setText("");
                empLastName.setText("");
                empEmail.setText("");
                course_tutoring.setSelectedIndex(0);
                position.setSelectedIndex(0);
            }
        }catch(SQLException e){
            
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(FitnessManagerAsstDashboard.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_deleteempbtnMousePressed

    private void viewEmpDatabtnMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_viewEmpDatabtnMousePressed
        try{
            con = DriverManager.getConnection(dataConn,username,"");
            prep = con.prepareStatement("SELECT * FROM employees");
            ResultSet rs = prep.executeQuery();
            DefaultTableModel model = (DefaultTableModel)EmployeeTable.getModel();
            while(rs.next()){
                model.addRow(new String[]{rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5)});
            }
            updateemployeeDB();
        }catch(SQLException e){
            
        }
    }//GEN-LAST:event_viewEmpDatabtnMousePressed

    private void EmployeeTableMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_EmployeeTableMousePressed
        DefaultTableModel RecordTable = (DefaultTableModel)EmployeeTable.getModel();
        int SelectedRows = EmployeeTable.getSelectedRow();

        employeeID.setText(RecordTable.getValueAt(SelectedRows, 1).toString());
        empFirstName.setText(RecordTable.getValueAt(SelectedRows, 2).toString());
        empLastName.setText(RecordTable.getValueAt(SelectedRows, 3).toString());
        empEmail.setText(RecordTable.getValueAt(SelectedRows, 4).toString());
        course_tutoring.setSelectedItem(RecordTable.getValueAt(SelectedRows, 4).toString());
        position.setSelectedItem(RecordTable.getValueAt(SelectedRows, 4).toString());
    }//GEN-LAST:event_EmployeeTableMousePressed

    private void viewEnqDatabtnMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_viewEnqDatabtnMousePressed
       try{
            con = DriverManager.getConnection(dataConn,username,"");
            prep = con.prepareStatement("SELECT * FROM enquiries");
            ResultSet rs = prep.executeQuery();
            DefaultTableModel model = (DefaultTableModel)EnquiryTable.getModel();
            while(rs.next()){
                model.addRow(new String[]{rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6)});
            }
            updateenqDB();
        }catch(SQLException e){
            
        } 
    }//GEN-LAST:event_viewEnqDatabtnMousePressed

    private void dashboardbtnMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_dashboardbtnMousePressed
        jTabbedPane1.setSelectedIndex(0);
    }//GEN-LAST:event_dashboardbtnMousePressed

    private void booksbtnMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_booksbtnMousePressed
        jTabbedPane1.setSelectedIndex(1);
    }//GEN-LAST:event_booksbtnMousePressed

    private void employeebtnMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_employeebtnMousePressed
        jTabbedPane1.setSelectedIndex(2);
    }//GEN-LAST:event_employeebtnMousePressed

    private void fitnessbtnMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_fitnessbtnMousePressed
//        this.setVisible(false);
//        new Menu().setVisible(true);
    }//GEN-LAST:event_fitnessbtnMousePressed

    private void enquiriesbtnMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_enquiriesbtnMousePressed
        jTabbedPane1.setSelectedIndex(3);
    }//GEN-LAST:event_enquiriesbtnMousePressed

    private void admissionbtnMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_admissionbtnMousePressed
        jTabbedPane1.setSelectedIndex(4);
    }//GEN-LAST:event_admissionbtnMousePressed

    private void durationActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_durationActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_durationActionPerformed

    private void resetcoursebtnMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_resetcoursebtnMousePressed
        courseID.setText("");
        courseName.setText("");
        fee.setText("");
        duration.setText("");
    }//GEN-LAST:event_resetcoursebtnMousePressed

    private void viewCourseDatabtnMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_viewCourseDatabtnMousePressed
        try{
            con = DriverManager.getConnection(dataConn,username,"");
            prep = con.prepareStatement("SELECT * FROM courses");
            ResultSet rs = prep.executeQuery();
            DefaultTableModel model = (DefaultTableModel)CourseTable.getModel();
            while(rs.next()){
                model.addRow(new String[]{rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5)});
            }
            updatecourseDB();
        }catch(SQLException e){
            
        } 
    }//GEN-LAST:event_viewCourseDatabtnMousePressed

    private void addcoursebtnMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_addcoursebtnMousePressed
        DefaultTableModel RecordTable = (DefaultTableModel)CourseTable.getModel();
        int SelectedRows = CourseTable.getSelectedRow();
        
        try{
            int Id = Integer.parseInt(RecordTable.getValueAt(SelectedRows, 0).toString());
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection(dataConn,username,"");
            prep = con.prepareStatement("INSERT INTO courses(courseID, name, fee, course_duration) VALUES(?,?,?,?) ");
            prep.setString(1, courseID.getText());
            prep.setString(2, courseName.getText());
            prep.setString(3, fee.getText());
            prep.setString(4, duration.getText());

            prep.executeUpdate();
            JOptionPane.showMessageDialog(this, "Course added successfully");
            updatecourseDB();
        } catch (SQLException ex) {

        } catch (ClassNotFoundException ex) {
            Logger.getLogger(FitnessManagerAsstDashboard.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_addcoursebtnMousePressed

    private void updatecoursebtnMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_updatecoursebtnMousePressed
        DefaultTableModel RecordTable = (DefaultTableModel)CourseTable.getModel();
        int SelectedRows = CourseTable.getSelectedRow();

        String[] choices = {"CourseID","Course Name","Fee","Course Duration","All"};
        int updateInput = JOptionPane.showOptionDialog(this, "Select a field to update", "Update Book Details", 0, 3, null, choices, choices[0]);
//        int id = Integer.parseInt(JOptionPane.showInputDialog(this, "Input ID of book(not BookID)"));
        
        if(updateInput==0){
            try{
                int Id = Integer.parseInt(RecordTable.getValueAt(SelectedRows, 0).toString());
                Class.forName("com.mysql.jdbc.Driver");
                con = DriverManager.getConnection(dataConn,username,"");
                prep = con.prepareStatement("UPDATE courses SET courseID = ? WHERE ID = ?");
                prep.setString(1, courseID.getText());
                prep.setInt(2, Id);
                
                prep.executeUpdate();
                JOptionPane.showMessageDialog(this, "Course details updated successfully");
                updatecourseDB();
            }catch(SQLException e){
                
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(FitnessManagerManDashboard.class.getName()).log(Level.SEVERE, null, ex);
            }
        }else if(updateInput == 1){
            try{
                int Id = Integer.parseInt(RecordTable.getValueAt(SelectedRows, 0).toString());
                Class.forName("com.mysql.jdbc.Driver");
                con = DriverManager.getConnection(dataConn,username,"");
                prep = con.prepareStatement("UPDATE courses SET name = ? WHERE ID = ?");
                prep.setString(1, courseName.getText());
                prep.setInt(2, Id);
                
                prep.executeUpdate();
                JOptionPane.showMessageDialog(this, "Course details updated successfully");
                updatecourseDB();
            }catch(SQLException e){
                
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(FitnessManagerManDashboard.class.getName()).log(Level.SEVERE, null, ex);
            }
        }else if(updateInput == 2){
            try{
                int Id = Integer.parseInt(RecordTable.getValueAt(SelectedRows, 0).toString());
                Class.forName("com.mysql.jdbc.Driver");
                con = DriverManager.getConnection(dataConn,username,"");
                prep = con.prepareStatement("UPDATE courses SET fee = ? WHERE ID = ?");
                prep.setString(1, fee.getText());
                prep.setInt(2, Id);
                
                prep.executeUpdate();
                JOptionPane.showMessageDialog(this, "Course details updated successfully");
                updatecourseDB();
            }catch(SQLException e){
                
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(FitnessManagerManDashboard.class.getName()).log(Level.SEVERE, null, ex);
            }
        }else if(updateInput == 3){
            try{
                int Id = Integer.parseInt(RecordTable.getValueAt(SelectedRows, 0).toString());
                Class.forName("com.mysql.jdbc.Driver");
                con = DriverManager.getConnection(dataConn,username,"");
                prep = con.prepareStatement("UPDATE courses SET course_duration = ? WHERE ID = ?");
                prep.setString(1, duration.getText());
                prep.setInt(2, Id);
                
                prep.executeUpdate();
                JOptionPane.showMessageDialog(this, "Course details updated successfully");
                updatecourseDB();
            }catch(SQLException e){
                
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(FitnessManagerManDashboard.class.getName()).log(Level.SEVERE, null, ex);
            }
        }else if(updateInput == 4){
            try{
                int Id = Integer.parseInt(RecordTable.getValueAt(SelectedRows, 0).toString());
                Class.forName("com.mysql.jdbc.Driver");
                con = DriverManager.getConnection(dataConn,username,"");
                prep = con.prepareStatement("UPDATE courses SET courseID = ?, name = ?, fee = ?, course_duration = ? WHERE ID = ?");
                prep.setString(1, courseID.getText());
                prep.setString(2, courseName.getText());
                prep.setString(3, fee.getText());
                prep.setString(4, duration.getText());
                prep.setInt(5, Id);

                prep.executeUpdate();
                JOptionPane.showMessageDialog(this, "Course details updated successfully");
                updatecourseDB();
            } catch (SQLException ex) {

            } catch (ClassNotFoundException ex) {
                Logger.getLogger(FitnessManagerAsstDashboard.class.getName()).log(Level.SEVERE, null, ex);
            }
        }        
    }//GEN-LAST:event_updatecoursebtnMousePressed

    private void delcoursebtnMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_delcoursebtnMousePressed
        DefaultTableModel RecordTable = (DefaultTableModel)CourseTable.getModel();
        int SelectedRows = CourseTable.getSelectedRow();
        try{
            int id = Integer.parseInt(RecordTable.getValueAt(SelectedRows, 0).toString());
            int deleteItem = JOptionPane.showConfirmDialog(null, "Confirm if you want to delete item", "Warning", JOptionPane.YES_NO_OPTION);
            if(deleteItem==JOptionPane.YES_OPTION){
                Class.forName("com.mysql.cj.jdbc.Driver"); 
                con = DriverManager.getConnection(dataConn,username,"");
                prep = con.prepareStatement("DELETE FROM courses WHERE ID = ?");
                prep.setInt(1, id);

                prep.executeUpdate();
                JOptionPane.showMessageDialog(this, "Course deleted successfully");
                updatecourseDB();
                
                courseID.setText("");
                courseID.requestFocus();
                courseName.setText("");
                fee.setText("");
                duration.setText("");
            }
        }catch(SQLException e){
            
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(FitnessManagerAsstDashboard.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_delcoursebtnMousePressed

    private void batchIDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_batchIDActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_batchIDActionPerformed

    private void viewBatchDatabtnMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_viewBatchDatabtnMousePressed
        try{
            con = DriverManager.getConnection(dataConn,username,"");
            prep = con.prepareStatement("SELECT * FROM batches");
            ResultSet rs = prep.executeQuery();
            DefaultTableModel model = (DefaultTableModel)BatchTable.getModel();
            while(rs.next()){
                model.addRow(new String[]{rs.getString(1),rs.getString(2),rs.getString(3)});
            }
            updatebatchDB();
        }catch(SQLException e){
            
        } 
    }//GEN-LAST:event_viewBatchDatabtnMousePressed

    private void updateBatchbtnMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_updateBatchbtnMousePressed
        DefaultTableModel RecordTable = (DefaultTableModel)BatchTable.getModel();
        int SelectedRows = BatchTable.getSelectedRow();

        String[] choices = {"BatchID","Course"};
        int updateInput = JOptionPane.showOptionDialog(this, "Select a field to update", "Update Batch Details", 0, 3, null, choices, choices[0]);
//        int id = Integer.parseInt(JOptionPane.showInputDialog(this, "Input ID of book(not BookID)"));
        
        if(updateInput==0){
            try{
                int Id = Integer.parseInt(RecordTable.getValueAt(SelectedRows, 0).toString());
                Class.forName("com.mysql.jdbc.Driver");
                con = DriverManager.getConnection(dataConn,username,"");
                prep = con.prepareStatement("UPDATE batches SET batchID = ? WHERE ID = ?");
                prep.setString(1, batchID.getText());
                prep.setInt(2, Id);
                
                prep.executeUpdate();
                JOptionPane.showMessageDialog(this, "Batch details updated successfully");
                updatebatchDB();
            }catch(SQLException e){
                
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(FitnessManagerManDashboard.class.getName()).log(Level.SEVERE, null, ex);
            }
        }else if(updateInput == 1){
            try{
                int Id = Integer.parseInt(RecordTable.getValueAt(SelectedRows, 0).toString());
                Class.forName("com.mysql.jdbc.Driver");
                con = DriverManager.getConnection(dataConn,username,"");
                prep = con.prepareStatement("UPDATE batches SET course = ? WHERE ID = ?");
                prep.setString(1, (String) batch_courses.getSelectedItem());
                prep.setInt(2, Id);
                
                prep.executeUpdate();
                JOptionPane.showMessageDialog(this, "Batch details updated successfully");
                updatebatchDB();
            }catch(SQLException e){
                
            } catch (ClassNotFoundException ex) {
                Logger.getLogger(FitnessManagerManDashboard.class.getName()).log(Level.SEVERE, null, ex);
            }
        }   
    }//GEN-LAST:event_updateBatchbtnMousePressed

    private void addBatchbtnMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_addBatchbtnMousePressed
        
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection(dataConn,username,"");
            prep = con.prepareStatement("INSERT INTO batches(batchID,course) VALUES (?,?)");
            prep.setString(1, batchID.getText());
            prep.setString(2, (String) batch_courses.getSelectedItem());

            prep.executeUpdate();
            JOptionPane.showMessageDialog(this, "Batch details added successfully");
            updatebatchDB();
//            prep = con.prepareStatement("UPDATE batches tbl1 INNER JOIN customers tbl2 ON tbl1.course = tbl2.course_registered SET tbl1.customerID = tbl2.customerID;");
//            prep.executeUpdate();
//            updatebatchDB();
//            
//            prep = con.prepareStatement("UPDATE batches tbl1 INNER JOIN customers tbl2 ON tbl1.customerID = tbl2.customerID SET tbl1.firstname = tbl2.firstname,tbl1.lastname = tbl2.lastname;");
//            prep.executeUpdate();
//            updatebatchDB();
            
        } catch (SQLException ex) {

        } catch (ClassNotFoundException ex) {
            Logger.getLogger(FitnessManagerAsstDashboard.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_addBatchbtnMousePressed

    private void delBatchbtnMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_delBatchbtnMousePressed
        DefaultTableModel RecordTable = (DefaultTableModel)BatchTable.getModel();
        int SelectedRows = BatchTable.getSelectedRow();
        try{
            int id = Integer.parseInt(RecordTable.getValueAt(SelectedRows, 0).toString());
            int deleteItem = JOptionPane.showConfirmDialog(null, "Confirm if you want to delete item", "Warning", JOptionPane.YES_NO_OPTION);
            if(deleteItem==JOptionPane.YES_OPTION){
                Class.forName("com.mysql.cj.jdbc.Driver"); 
                con = DriverManager.getConnection(dataConn,username,"");
                prep = con.prepareStatement("DELETE FROM batches WHERE ID = ?");
                prep.setInt(1, id);

                prep.executeUpdate();
                JOptionPane.showMessageDialog(this, "Batch deleted successfully");
                updatebatchDB();
                
                batchID.setText("");
                batchID.requestFocus();
                batch_courses.setSelectedIndex(0);
            }
        }catch(SQLException e){
            
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(FitnessManagerAsstDashboard.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_delBatchbtnMousePressed

    private void coursesbtnMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_coursesbtnMousePressed
        jTabbedPane1.setSelectedIndex(5);
    }//GEN-LAST:event_coursesbtnMousePressed

    private void batchesbtnMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_batchesbtnMousePressed
        jTabbedPane1.setSelectedIndex(6);
    }//GEN-LAST:event_batchesbtnMousePressed

    private void schedulesbtnMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_schedulesbtnMousePressed
       jTabbedPane1.setSelectedIndex(7);
    }//GEN-LAST:event_schedulesbtnMousePressed

    private void jLabel78MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel78MousePressed
        jTabbedPane1.setSelectedIndex(5);
    }//GEN-LAST:event_jLabel78MousePressed

    private void batch701MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_batch701MousePressed
        
    }//GEN-LAST:event_batch701MousePressed

    private void batch701btnMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_batch701btnMousePressed
        try{
            con = DriverManager.getConnection(dataConn,username,"");
            prep = con.prepareStatement("SELECT firstname, lastname FROM customers WHERE batch_number = 701;");
            ResultSet rs = prep.executeQuery();
            DefaultTableModel model = (DefaultTableModel)batch701.getModel();
            while(rs.next()){
                model.addRow(new String[]{rs.getString(1),rs.getString(2)});
            }
            updatebatch701DB();
        }catch(SQLException e){
            
        } 
    }//GEN-LAST:event_batch701btnMousePressed

    private void batch721btnMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_batch721btnMousePressed
        try{
            con = DriverManager.getConnection(dataConn,username,"");
            prep = con.prepareStatement("SELECT firstname, lastname FROM customers WHERE batch_number = 721;");
            ResultSet rs = prep.executeQuery();
            DefaultTableModel model = (DefaultTableModel)batch721.getModel();
            while(rs.next()){
                model.addRow(new String[]{rs.getString(1),rs.getString(2)});
            }
            updatebatch721DB();
        }catch(SQLException e){
            
        } 
    }//GEN-LAST:event_batch721btnMousePressed

    private void batch721MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_batch721MousePressed
        // TODO add your handling code here:
    }//GEN-LAST:event_batch721MousePressed

    private void batch798btnMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_batch798btnMousePressed
        try{
            con = DriverManager.getConnection(dataConn,username,"");
            prep = con.prepareStatement("SELECT firstname, lastname FROM customers WHERE batch_number = 798;");
            ResultSet rs = prep.executeQuery();
            DefaultTableModel model = (DefaultTableModel)batch798.getModel();
            while(rs.next()){
                model.addRow(new String[]{rs.getString(1),rs.getString(2)});
            }
            updatebatch798DB();
        }catch(SQLException e){
            
        } 
    }//GEN-LAST:event_batch798btnMousePressed

    private void batch798MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_batch798MousePressed
        
    }//GEN-LAST:event_batch798MousePressed

    private void batch745btnMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_batch745btnMousePressed
        try{
            con = DriverManager.getConnection(dataConn,username,"");
            prep = con.prepareStatement("SELECT firstname, lastname FROM customers WHERE batch_number = 745;");
            ResultSet rs = prep.executeQuery();
            DefaultTableModel model = (DefaultTableModel)batch745.getModel();
            while(rs.next()){
                model.addRow(new String[]{rs.getString(1),rs.getString(2)});
            }
            updatebatch745DB();
        }catch(SQLException e){
            
        } 
         
    }//GEN-LAST:event_batch745btnMousePressed

    private void batch745MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_batch745MousePressed
        // TODO add your handling code here:
    }//GEN-LAST:event_batch745MousePressed

    private void batch789btnMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_batch789btnMousePressed
        try{
            con = DriverManager.getConnection(dataConn,username,"");
            prep = con.prepareStatement("SELECT firstname, lastname FROM customers WHERE batch_number = 789;");
            ResultSet rs = prep.executeQuery();
            DefaultTableModel model = (DefaultTableModel)batch789.getModel();
            while(rs.next()){
                model.addRow(new String[]{rs.getString(1),rs.getString(2)});
            }
            updatebatch789DB();
        }catch(SQLException e){
            
        }
    }//GEN-LAST:event_batch789btnMousePressed

    private void batch789MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_batch789MousePressed
        // TODO add your handling code here:
    }//GEN-LAST:event_batch789MousePressed

    private void batch709btnMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_batch709btnMousePressed
        try{
            con = DriverManager.getConnection(dataConn,username,"");
            prep = con.prepareStatement("SELECT firstname, lastname FROM customers WHERE batch_number = 709;");
            ResultSet rs = prep.executeQuery();
            DefaultTableModel model = (DefaultTableModel)batch709.getModel();
            while(rs.next()){
                model.addRow(new String[]{rs.getString(1),rs.getString(2)});
            }
            updatebatch709DB();
        }catch(SQLException e){
            
        }
    }//GEN-LAST:event_batch709btnMousePressed

    private void batch709MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_batch709MousePressed
        // TODO add your handling code here:
    }//GEN-LAST:event_batch709MousePressed

    private void batch767btnMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_batch767btnMousePressed
        try{
            con = DriverManager.getConnection(dataConn,username,"");
            prep = con.prepareStatement("SELECT firstname, lastname FROM customers WHERE batch_number = 767;");
            ResultSet rs = prep.executeQuery();
            DefaultTableModel model = (DefaultTableModel)batch767.getModel();
            while(rs.next()){
                model.addRow(new String[]{rs.getString(1),rs.getString(2)});
            }
            updatebatch767DB();
        }catch(SQLException e){
            
        }
    }//GEN-LAST:event_batch767btnMousePressed

    private void batch767MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_batch767MousePressed
        // TODO add your handling code here:
    }//GEN-LAST:event_batch767MousePressed

    private void batch734btnMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_batch734btnMousePressed
        try{
            con = DriverManager.getConnection(dataConn,username,"");
            prep = con.prepareStatement("SELECT firstname, lastname FROM customers WHERE batch_number = 734;");
            ResultSet rs = prep.executeQuery();
            DefaultTableModel model = (DefaultTableModel)batch734.getModel();
            while(rs.next()){
                model.addRow(new String[]{rs.getString(1),rs.getString(2)});
            }
            updatebatch734DB();
        }catch(SQLException e){
            
        }
    }//GEN-LAST:event_batch734btnMousePressed

    private void batch734MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_batch734MousePressed
        // TODO add your handling code here:
    }//GEN-LAST:event_batch734MousePressed

    private void batch777btnMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_batch777btnMousePressed
        try{
            con = DriverManager.getConnection(dataConn,username,"");
            prep = con.prepareStatement("SELECT firstname, lastname FROM customers WHERE batch_number = 777;");
            ResultSet rs = prep.executeQuery();
            DefaultTableModel model = (DefaultTableModel)batch777.getModel();
            while(rs.next()){
                model.addRow(new String[]{rs.getString(1),rs.getString(2)});
            }
            updatebatch777DB();
        }catch(SQLException e){
            
        }
    }//GEN-LAST:event_batch777btnMousePressed

    private void batch777MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_batch777MousePressed
        // TODO add your handling code here:
    }//GEN-LAST:event_batch777MousePressed

    private void batch788btnMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_batch788btnMousePressed
        try{
            con = DriverManager.getConnection(dataConn,username,"");
            prep = con.prepareStatement("SELECT firstname, lastname FROM customers WHERE batch_number = 788;");
            ResultSet rs = prep.executeQuery();
            DefaultTableModel model = (DefaultTableModel)batch788.getModel();
            while(rs.next()){
                model.addRow(new String[]{rs.getString(1),rs.getString(2)});
            }
            updatebatch788DB();
        }catch(SQLException e){
            
        }
    }//GEN-LAST:event_batch788btnMousePressed

    private void batch788MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_batch788MousePressed
        // TODO add your handling code here:
    }//GEN-LAST:event_batch788MousePressed

    private void batch799btnMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_batch799btnMousePressed
        try{
            con = DriverManager.getConnection(dataConn,username,"");
            prep = con.prepareStatement("SELECT firstname, lastname FROM customers WHERE batch_number = 799;");
            ResultSet rs = prep.executeQuery();
            DefaultTableModel model = (DefaultTableModel)batch799.getModel();
            while(rs.next()){
                model.addRow(new String[]{rs.getString(1),rs.getString(2)});
            }
            updatebatch799DB();
        }catch(SQLException e){
            
        }
    }//GEN-LAST:event_batch799btnMousePressed

    private void batch799MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_batch799MousePressed
        // TODO add your handling code here:
    }//GEN-LAST:event_batch799MousePressed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(FitnessManagerManDashboard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(FitnessManagerManDashboard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(FitnessManagerManDashboard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FitnessManagerManDashboard.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FitnessManagerManDashboard().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel Admission;
    private javax.swing.JTable BatchTable;
    private javax.swing.JPanel Batches;
    private javax.swing.JTable BookDetails;
    private javax.swing.JPanel Books;
    private javax.swing.JTable CourseTable;
    private javax.swing.JPanel Courses;
    private javax.swing.JTable CustomerAdmission;
    private javax.swing.JPanel Dashboard;
    private javax.swing.JPanel Employee;
    private javax.swing.JTable EmployeeTable;
    private javax.swing.JPanel Enquiries;
    private javax.swing.JTable EnquiryTable;
    private javax.swing.JLabel ManagerName;
    private javax.swing.JPanel Schedules;
    private FitnessManager.PanelRound addBatchbtn;
    private FitnessManager.PanelRound addbookbtn;
    private FitnessManager.PanelRound addcoursebtn;
    private FitnessManager.PanelRound adddeetsbtn;
    private FitnessManager.PanelRound addempbtn;
    private FitnessManager.PanelRound admissionbtn;
    private javax.swing.JTable batch701;
    private javax.swing.JLabel batch701btn;
    private javax.swing.JTable batch709;
    private javax.swing.JLabel batch709btn;
    private javax.swing.JTable batch721;
    private javax.swing.JLabel batch721btn;
    private javax.swing.JTable batch723;
    private javax.swing.JTable batch730;
    private javax.swing.JTable batch734;
    private javax.swing.JLabel batch734btn;
    private javax.swing.JTable batch745;
    private javax.swing.JLabel batch745btn;
    private javax.swing.JTable batch767;
    private javax.swing.JLabel batch767btn;
    private javax.swing.JTable batch777;
    private javax.swing.JLabel batch777btn;
    private javax.swing.JTable batch788;
    private javax.swing.JLabel batch788btn;
    private javax.swing.JTable batch789;
    private javax.swing.JLabel batch789btn;
    private javax.swing.JTable batch798;
    private javax.swing.JLabel batch798btn;
    private javax.swing.JTable batch799;
    private javax.swing.JLabel batch799btn;
    private javax.swing.JTextField batchID;
    private javax.swing.JComboBox<String> batch_courses;
    private FitnessManager.PanelRound batchesbtn;
    private javax.swing.JTextField bookID;
    private FitnessManager.PanelRound booksbtn;
    private javax.swing.JTextField courseID;
    private javax.swing.JTextField courseName;
    private javax.swing.JComboBox<String> course_tutoring;
    private FitnessManager.PanelRound coursesbtn;
    private javax.swing.JTextField customerID;
    private FitnessManager.PanelRound dashboardbtn;
    private FitnessManager.PanelRound delBatchbtn;
    private FitnessManager.PanelRound delcoursebtn;
    private FitnessManager.PanelRound deletebookbtn;
    private FitnessManager.PanelRound deleteempbtn;
    private javax.swing.JTextField duration;
    private javax.swing.JTextField empEmail;
    private javax.swing.JTextField empFirstName;
    private javax.swing.JTextField empLastName;
    private javax.swing.JTextField employeeID;
    private FitnessManager.PanelRound employeebtn;
    private FitnessManager.PanelRound enquiriesbtn;
    private javax.swing.JTextField fee;
    private FitnessManager.PanelRound fitnessbtn;
    private com.toedter.calendar.JCalendar jCalendar1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel39;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel40;
    private javax.swing.JLabel jLabel41;
    private javax.swing.JLabel jLabel42;
    private javax.swing.JLabel jLabel43;
    private javax.swing.JLabel jLabel44;
    private javax.swing.JLabel jLabel45;
    private javax.swing.JLabel jLabel46;
    private javax.swing.JLabel jLabel47;
    private javax.swing.JLabel jLabel48;
    private javax.swing.JLabel jLabel49;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel50;
    private javax.swing.JLabel jLabel51;
    private javax.swing.JLabel jLabel52;
    private javax.swing.JLabel jLabel53;
    private javax.swing.JLabel jLabel54;
    private javax.swing.JLabel jLabel55;
    private javax.swing.JLabel jLabel56;
    private javax.swing.JLabel jLabel57;
    private javax.swing.JLabel jLabel58;
    private javax.swing.JLabel jLabel59;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel60;
    private javax.swing.JLabel jLabel61;
    private javax.swing.JLabel jLabel62;
    private javax.swing.JLabel jLabel63;
    private javax.swing.JLabel jLabel64;
    private javax.swing.JLabel jLabel65;
    private javax.swing.JLabel jLabel66;
    private javax.swing.JLabel jLabel67;
    private javax.swing.JLabel jLabel68;
    private javax.swing.JLabel jLabel69;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel70;
    private javax.swing.JLabel jLabel71;
    private javax.swing.JLabel jLabel72;
    private javax.swing.JLabel jLabel73;
    private javax.swing.JLabel jLabel74;
    private javax.swing.JLabel jLabel75;
    private javax.swing.JLabel jLabel76;
    private javax.swing.JLabel jLabel77;
    private javax.swing.JLabel jLabel78;
    private javax.swing.JLabel jLabel79;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel80;
    private javax.swing.JLabel jLabel83;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JLabel jLabel90;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane10;
    private javax.swing.JScrollPane jScrollPane11;
    private javax.swing.JScrollPane jScrollPane12;
    private javax.swing.JScrollPane jScrollPane13;
    private javax.swing.JScrollPane jScrollPane14;
    private javax.swing.JScrollPane jScrollPane15;
    private javax.swing.JScrollPane jScrollPane16;
    private javax.swing.JScrollPane jScrollPane17;
    private javax.swing.JScrollPane jScrollPane18;
    private javax.swing.JScrollPane jScrollPane19;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JScrollPane jScrollPane8;
    private javax.swing.JScrollPane jScrollPane9;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTextField name;
    private javax.swing.JPanel panelHeader;
    private javax.swing.JPanel panelMenu;
    private FitnessManager.PanelRound panelRound1;
    private FitnessManager.PanelRound panelRound10;
    private FitnessManager.PanelRound panelRound11;
    private FitnessManager.PanelRound panelRound12;
    private FitnessManager.PanelRound panelRound13;
    private FitnessManager.PanelRound panelRound14;
    private FitnessManager.PanelRound panelRound15;
    private FitnessManager.PanelRound panelRound16;
    private FitnessManager.PanelRound panelRound17;
    private FitnessManager.PanelRound panelRound18;
    private FitnessManager.PanelRound panelRound19;
    private FitnessManager.PanelRound panelRound2;
    private FitnessManager.PanelRound panelRound20;
    private FitnessManager.PanelRound panelRound21;
    private FitnessManager.PanelRound panelRound22;
    private FitnessManager.PanelRound panelRound23;
    private FitnessManager.PanelRound panelRound24;
    private FitnessManager.PanelRound panelRound25;
    private FitnessManager.PanelRound panelRound26;
    private FitnessManager.PanelRound panelRound27;
    private FitnessManager.PanelRound panelRound28;
    private FitnessManager.PanelRound panelRound29;
    private FitnessManager.PanelRound panelRound3;
    private FitnessManager.PanelRound panelRound30;
    private FitnessManager.PanelRound panelRound31;
    private FitnessManager.PanelRound panelRound32;
    private FitnessManager.PanelRound panelRound33;
    private FitnessManager.PanelRound panelRound34;
    private FitnessManager.PanelRound panelRound35;
    private FitnessManager.PanelRound panelRound36;
    private FitnessManager.PanelRound panelRound37;
    private FitnessManager.PanelRound panelRound38;
    private FitnessManager.PanelRound panelRound39;
    private FitnessManager.PanelRound panelRound4;
    private FitnessManager.PanelRound panelRound40;
    private FitnessManager.PanelRound panelRound41;
    private FitnessManager.PanelRound panelRound42;
    private FitnessManager.PanelRound panelRound43;
    private FitnessManager.PanelRound panelRound44;
    private FitnessManager.PanelRound panelRound45;
    private FitnessManager.PanelRound panelRound46;
    private FitnessManager.PanelRound panelRound47;
    private FitnessManager.PanelRound panelRound5;
    private FitnessManager.PanelRound panelRound6;
    private FitnessManager.PanelRound panelRound7;
    private FitnessManager.PanelRound panelRound8;
    private FitnessManager.PanelRound panelRound9;
    private javax.swing.JComboBox<String> position;
    private javax.swing.JTextField price;
    private javax.swing.JTextField quantity;
    private FitnessManager.PanelRound resetbookbtn;
    private FitnessManager.PanelRound resetbtn;
    private FitnessManager.PanelRound resetcoursebtn;
    private FitnessManager.PanelRound resetempbtn;
    private FitnessManager.PanelRound schedulesbtn;
    private FitnessManager.PanelRound updateBatchbtn;
    private FitnessManager.PanelRound updatebookbtn;
    private FitnessManager.PanelRound updatecoursebtn;
    private FitnessManager.PanelRound updatedeetsbtn;
    private FitnessManager.PanelRound updateempbtn;
    private FitnessManager.PanelRound viewBatchDatabtn;
    private FitnessManager.PanelRound viewCourseDatabtn;
    private FitnessManager.PanelRound viewCustomerDatabtn;
    private FitnessManager.PanelRound viewData;
    private FitnessManager.PanelRound viewEmpDatabtn;
    private FitnessManager.PanelRound viewEnqDatabtn;
    // End of variables declaration//GEN-END:variables
}
